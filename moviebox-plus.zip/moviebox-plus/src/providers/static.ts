import type { ContentItem } from '../types/content';
import { sourcesFor, tagItem } from './common';
import type { ContentProvider } from './types';

/** Provider for add-ons that embed their items directly in the manifest. */
export function createStaticProvider(id: string, name: string, items: ContentItem[]): ContentProvider {
  return {
    id,
    name,
    getCatalog: async () => items.map((i) => tagItem(id, name, i)),
    getSources: async (item, ep) => sourcesFor(item, ep),
  };
}
