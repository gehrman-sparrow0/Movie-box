import { fetchJson } from '../lib/http';
import { catalogSchema, formatIssues } from '../schemas/addon';
import { sourcesFor, tagItem } from './common';
import type { CatalogItem } from '../types/content';
import type { ContentProvider } from './types';

/**
 * Provider that loads a JSON catalog from an HTTPS endpoint. The response is
 * fetched with the hardened fetchJson (no credentials/redirects, size cap) and
 * validated against the strict catalog schema before use.
 */
export function createRemoteProvider(id: string, name: string, catalogUrl: string): ContentProvider {
  let cached: Promise<CatalogItem[]> | null = null;

  const load = (signal?: AbortSignal): Promise<CatalogItem[]> => {
    cached ??= (async () => {
      const data = await fetchJson(catalogUrl, { signal });
      const parsed = catalogSchema.safeParse(data);
      if (!parsed.success) {
        throw new Error(`Catalog is invalid: ${formatIssues(parsed.error, 3).join('; ')}`);
      }
      return parsed.data.items.map((i) => tagItem(id, name, i));
    })().catch((e) => {
      cached = null; // allow retry
      throw e;
    });
    return cached;
  };

  return {
    id,
    name,
    getCatalog: load,
    getSources: async (item, ep) => sourcesFor(item, ep),
  };
}
