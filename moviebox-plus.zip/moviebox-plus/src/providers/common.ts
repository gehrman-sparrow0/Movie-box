import type { CatalogItem, ContentItem, StreamSource } from '../types/content';

export function sourcesFor(item: ContentItem, episodeNumber?: number): StreamSource[] {
  if (episodeNumber !== undefined && item.episodes) {
    return item.episodes.find((e) => e.number === episodeNumber)?.sources ?? [];
  }
  return item.sources;
}

export function tagItem(origin: string, originName: string, item: ContentItem): CatalogItem {
  return { ...item, id: `${origin}~${item.id}`, origin, originName };
}
