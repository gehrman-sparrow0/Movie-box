import { sampleContent } from '../data/sampleContent';
import { sourcesFor, tagItem } from './common';
import type { ContentProvider } from './types';

export const BUILTIN_ID = 'builtin';
const NAME = 'Built-in samples';

export const builtinProvider: ContentProvider = {
  id: BUILTIN_ID,
  name: NAME,
  getCatalog: async () => sampleContent.map((i) => tagItem(BUILTIN_ID, NAME, i)),
  getSources: async (item, ep) => sourcesFor(item, ep),
};
