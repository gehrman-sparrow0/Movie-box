import type { AddonManifest } from '../types/addon';
import { createRemoteProvider } from './remote';
import { createStaticProvider } from './static';
import type { ContentProvider } from './types';

export function createProvider(manifest: AddonManifest): ContentProvider {
  const p = manifest.provider;
  return p.kind === 'static'
    ? createStaticProvider(manifest.id, manifest.name, p.items)
    : createRemoteProvider(manifest.id, manifest.name, p.catalogUrl);
}

export type { ContentProvider } from './types';
