import type { CatalogItem, ContentItem, StreamSource } from '../types/content';

/**
 * Contract every content provider implements. Providers are DATA-driven:
 * add-ons never ship executable code, they only describe a catalog
 * (inline "static" items or a "remote" JSON catalog endpoint).
 */
export interface ContentProvider {
  /** Add-on id (or "builtin"). Used as the namespace for item ids. */
  readonly id: string;
  readonly name: string;
  /** Content metadata exposed by this provider. */
  getCatalog(signal?: AbortSignal): Promise<CatalogItem[]>;
  /** Authorized streaming sources for an item (or one of its episodes). */
  getSources(item: ContentItem, episodeNumber?: number): Promise<StreamSource[]>;
}
