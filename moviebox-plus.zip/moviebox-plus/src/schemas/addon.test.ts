import { describe, expect, it } from 'vitest';
import sampleAddon from '../../public/addons/sample-addon.json';
import sampleRemote from '../../public/addons/sample-remote-addon.json';
import sampleCatalog from '../../public/addons/sample-catalog.json';
import sampleRepo from '../../public/repo/sample-repository.json';
import { addonManifestSchema, catalogSchema, repositoryManifestSchema } from './addon';

describe('addonManifestSchema', () => {
  it('accepts the sample add-ons and catalog', () => {
    expect(addonManifestSchema.safeParse(sampleAddon).success).toBe(true);
    expect(addonManifestSchema.safeParse(sampleRemote).success).toBe(true);
    expect(catalogSchema.safeParse(sampleCatalog).success).toBe(true);
  });

  it('rejects unknown properties (strict)', () => {
    expect(addonManifestSchema.safeParse({ ...sampleAddon, script: 'alert(1)' }).success).toBe(false);
  });

  it('rejects a bad id and a bad version', () => {
    expect(addonManifestSchema.safeParse({ ...sampleAddon, id: 'Not Valid' }).success).toBe(false);
    expect(addonManifestSchema.safeParse({ ...sampleAddon, version: '1.0' }).success).toBe(false);
  });

  it('rejects http and javascript URLs', () => {
    expect(addonManifestSchema.safeParse({ ...sampleAddon, homepage: 'http://example.com' }).success).toBe(false);
    expect(addonManifestSchema.safeParse({ ...sampleAddon, icon: 'javascript:alert(1)' }).success).toBe(false);
  });

  it('rejects unsupported stream types and unsafe media URLs', () => {
    const item = (source: object) => ({
      ...sampleAddon,
      provider: {
        kind: 'static',
        items: [{ ...sampleAddon.provider.items[0], sources: [source] }],
      },
    });
    expect(addonManifestSchema.safeParse(item({ url: 'https://example.com/a.flv', type: 'rtmp' })).success).toBe(false);
    expect(addonManifestSchema.safeParse(item({ url: 'https://192.168.0.2/a.mp4', type: 'mp4' })).success).toBe(false);
    expect(addonManifestSchema.safeParse(item({ url: 'https://example.com/a.mp4', type: 'mp4' })).success).toBe(true);
  });

  it('requires a content rights statement', () => {
    const { contentRights: _omit, ...rest } = sampleAddon;
    expect(addonManifestSchema.safeParse(rest).success).toBe(false);
  });
});

describe('repositoryManifestSchema', () => {
  it('accepts the sample repository', () => {
    expect(repositoryManifestSchema.safeParse(sampleRepo).success).toBe(true);
  });

  it('rejects duplicate add-on ids', () => {
    const dup = { ...sampleRepo, addons: [sampleRepo.addons[0], sampleRepo.addons[0]] };
    expect(repositoryManifestSchema.safeParse(dup).success).toBe(false);
  });

  it('rejects an unsafe absolute manifest URL', () => {
    const bad = { ...sampleRepo, addons: [{ ...sampleRepo.addons[0], manifestUrl: 'http://example.com/a.json' }] };
    expect(repositoryManifestSchema.safeParse(bad).success).toBe(false);
  });
});
