import { z } from 'zod';
import { isRelativeRef, isUrlAllowed } from '../lib/security';

const ADDON_ID_RE = /^[a-z0-9]+(\.[a-z0-9-]+)+$/; // reverse-DNS, e.g. com.example.my-addon
const REPO_ID_RE = /^[a-z0-9][a-z0-9-]{2,63}$/;
const ITEM_ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;
const SEMVER_RE = /^\d+\.\d+\.\d+(-[0-9A-Za-z.-]+)?$/;

/** Absolute HTTPS URL that passes the SSRF policy. */
export const safeUrl = z
  .string()
  .max(2048)
  .refine((v) => isUrlAllowed(v), { message: 'Must be a public HTTPS URL' });

/** Absolute safe URL or a relative reference resolved later against the manifest URL. */
export const urlOrRelative = z
  .string()
  .max(2048)
  .refine((v) => isRelativeRef(v) || isUrlAllowed(v), {
    message: 'Must be a public HTTPS URL or a relative path',
  });

export const contentTypeSchema = z.enum(['movie', 'anime']);

export const streamSourceSchema = z
  .object({
    url: safeUrl,
    type: z.enum(['mp4', 'webm', 'hls']),
    label: z.string().min(1).max(40).optional(),
  })
  .strict();

export const episodeSchema = z
  .object({
    number: z.number().int().min(0).max(10000),
    title: z.string().max(120),
    sources: z.array(streamSourceSchema).max(10),
  })
  .strict();

export const contentItemSchema = z
  .object({
    id: z.string().regex(ITEM_ID_RE),
    title: z.string().min(1).max(120),
    type: contentTypeSchema,
    year: z.number().int().min(1888).max(2100),
    rating: z.number().min(0).max(10),
    genres: z.array(z.string().min(1).max(30)).max(8),
    synopsis: z.string().max(1500),
    durationMinutes: z.number().int().min(1).max(1000).optional(),
    poster: safeUrl.optional(),
    backdrop: safeUrl.optional(),
    sources: z.array(streamSourceSchema).max(10).default([]),
    episodes: z.array(episodeSchema).max(500).optional(),
  })
  .strict();

const staticProviderSchema = z
  .object({
    kind: z.literal('static'),
    items: z.array(contentItemSchema).max(200),
  })
  .strict();

const remoteProviderSchema = z
  .object({
    kind: z.literal('remote'),
    catalogUrl: urlOrRelative,
  })
  .strict();

export const providerSchema = z.discriminatedUnion('kind', [staticProviderSchema, remoteProviderSchema]);

export const addonManifestSchema = z
  .object({
    schemaVersion: z.literal(1),
    id: z.string().min(3).max(100).regex(ADDON_ID_RE),
    name: z.string().min(1).max(60),
    version: z.string().regex(SEMVER_RE),
    description: z.string().max(300),
    author: z.string().min(1).max(80),
    homepage: safeUrl.optional(),
    icon: safeUrl.optional(),
    types: z.array(contentTypeSchema).min(1).max(2),
    /** Statement of why the content is authorized (licence, ownership, subscription...). */
    contentRights: z.string().min(10).max(500),
    provider: providerSchema,
  })
  .strict();

/** Response format of a remote add-on catalog endpoint. */
export const catalogSchema = z
  .object({
    schemaVersion: z.literal(1),
    items: z.array(contentItemSchema).max(500),
  })
  .strict();

export const repositoryEntrySchema = z
  .object({
    id: z.string().min(3).max(100).regex(ADDON_ID_RE),
    name: z.string().min(1).max(60),
    version: z.string().regex(SEMVER_RE),
    description: z.string().max(300),
    manifestUrl: urlOrRelative,
    types: z.array(contentTypeSchema).min(1).max(2),
    icon: safeUrl.optional(),
  })
  .strict();

export const repositoryManifestSchema = z
  .object({
    schemaVersion: z.literal(1),
    id: z.string().regex(REPO_ID_RE),
    name: z.string().min(1).max(60),
    description: z.string().max(300).optional(),
    maintainer: z.string().max(80).optional(),
    addons: z.array(repositoryEntrySchema).max(200),
  })
  .strict()
  .superRefine((repo, ctx) => {
    const seen = new Set<string>();
    repo.addons.forEach((a, i) => {
      if (seen.has(a.id)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['addons', i, 'id'],
          message: `Duplicate add-on id "${a.id}"`,
        });
      }
      seen.add(a.id);
    });
  });

export function formatIssues(error: z.ZodError, limit = 6): string[] {
  const lines = error.issues
    .slice(0, limit)
    .map((i) => `${i.path.length ? i.path.join('.') : '(root)'}: ${i.message}`);
  if (error.issues.length > limit) lines.push(`…and ${error.issues.length - limit} more problems`);
  return lines;
}
