export const config = {
  /** Dev-only escape hatch. Always false in production builds. */
  allowInsecureDev: import.meta.env.DEV && import.meta.env.VITE_ALLOW_INSECURE_DEV === 'true',
  supabaseUrl: (import.meta.env.VITE_SUPABASE_URL as string | undefined) || undefined,
  supabaseAnonKey: (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) || undefined,
  maxManifestBytes: 512 * 1024,
  fetchTimeoutMs: 10_000,
};
