import { describe, expect, it } from 'vitest';
import { isUrlAllowed, parseSafeUrl, resolveUrl } from './security';

const strict = { allowInsecureDev: false };
const dev = { allowInsecureDev: true };

describe('parseSafeUrl', () => {
  it('accepts public HTTPS URLs', () => {
    expect(parseSafeUrl('https://example.com/repo.json', strict).hostname).toBe('example.com');
  });

  it.each([
    'http://example.com/a.json',
    'ftp://example.com/a.json',
    'javascript:alert(1)',
    'data:text/html,hi',
    'https://user:pass@example.com/',
    'https://example.com:8443/',
    'https://localhost/',
    'https://intranet/',
    'https://service.internal/',
    'https://127.0.0.1/',
    'https://10.0.0.5/',
    'https://172.16.4.1/',
    'https://192.168.1.10/',
    'https://169.254.169.254/latest/meta-data',
    'https://2130706433/', // decimal form of 127.0.0.1
    'https://[::1]/',
    'https://[fd00::1]/',
    'https://[::ffff:127.0.0.1]/',
    'not a url',
    '',
  ])('rejects %s', (url) => {
    expect(isUrlAllowed(url, strict)).toBe(false);
  });

  it('allows http and localhost only with the dev policy', () => {
    expect(isUrlAllowed('http://localhost:5173/repo.json', strict)).toBe(false);
    expect(isUrlAllowed('http://localhost:5173/repo.json', dev)).toBe(true);
  });

  it('still rejects credentials and non-http schemes in dev', () => {
    expect(isUrlAllowed('https://u:p@example.com/', dev)).toBe(false);
    expect(isUrlAllowed('javascript:alert(1)', dev)).toBe(false);
  });
});

describe('resolveUrl', () => {
  it('resolves relative references', () => {
    expect(resolveUrl('../addons/a.json', 'https://example.com/repo/r.json', strict)).toBe(
      'https://example.com/addons/a.json',
    );
  });
  it('rejects references that resolve to an unsafe target', () => {
    expect(() => resolveUrl('http://example.com/a.json', 'https://example.com/r.json', strict)).toThrow(/HTTPS/);
    expect(() => resolveUrl('https://127.0.0.1/a.json', 'https://example.com/r.json', strict)).toThrow();
  });
});
