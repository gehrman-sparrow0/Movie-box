import { config } from '../config';
import { parseSafeUrl, type UrlPolicy } from './security';

export type FetchErrorCode = 'network' | 'timeout' | 'http' | 'type' | 'size' | 'parse';

export class FetchError extends Error {
  readonly code: FetchErrorCode;
  constructor(message: string, code: FetchErrorCode) {
    super(message);
    this.name = 'FetchError';
    this.code = code;
  }
}

export interface FetchOptions {
  signal?: AbortSignal;
  maxBytes?: number;
  timeoutMs?: number;
  policy?: UrlPolicy;
}

async function readLimited(res: Response, max: number): Promise<string> {
  if (!res.body) {
    const text = await res.text();
    if (text.length > max) throw new FetchError('Response is too large.', 'size');
    return text;
  }
  const reader = res.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > max) {
      await reader.cancel();
      throw new FetchError('Response is too large.', 'size');
    }
    chunks.push(value);
  }
  const buf = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    buf.set(c, offset);
    offset += c.byteLength;
  }
  return new TextDecoder().decode(buf);
}

/**
 * Fetches JSON with: URL policy check, no cookies/credentials, no redirects
 * (redirects can bounce a request to an internal host), a timeout and a size cap.
 */
export async function fetchJson(rawUrl: string, options: FetchOptions = {}): Promise<unknown> {
  const url = parseSafeUrl(rawUrl, options.policy);
  const maxBytes = options.maxBytes ?? config.maxManifestBytes;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? config.fetchTimeoutMs);
  options.signal?.addEventListener('abort', () => controller.abort(), { once: true });

  try {
    let res: Response;
    try {
      res = await fetch(url.href, {
        method: 'GET',
        mode: 'cors',
        credentials: 'omit',
        redirect: 'error',
        cache: 'no-store',
        referrerPolicy: 'no-referrer',
        headers: { Accept: 'application/json' },
        signal: controller.signal,
      });
    } catch {
      if (controller.signal.aborted) {
        throw new FetchError('The request timed out or was cancelled.', 'timeout');
      }
      throw new FetchError(
        'Network error. The server may be offline, may not allow cross-origin requests (CORS), or tried to redirect.',
        'network',
      );
    }

    if (!res.ok) throw new FetchError(`The server responded with HTTP ${res.status}.`, 'http');

    const type = res.headers.get('content-type') ?? '';
    if (!/json|text\/plain/i.test(type)) {
      throw new FetchError(`Unexpected content type "${type || 'unknown'}". Expected JSON.`, 'type');
    }
    const length = Number(res.headers.get('content-length') ?? '0');
    if (length > maxBytes) throw new FetchError('Response is too large.', 'size');

    const text = await readLimited(res, maxBytes);
    try {
      return JSON.parse(text);
    } catch {
      throw new FetchError('The response is not valid JSON.', 'parse');
    }
  } finally {
    clearTimeout(timer);
  }
}
