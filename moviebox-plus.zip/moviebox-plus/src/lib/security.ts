import { config } from '../config';

export class SecurityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SecurityError';
  }
}

export interface UrlPolicy {
  /** Allows http:// and private hosts. Development only. */
  allowInsecureDev: boolean;
}

export const currentPolicy = (): UrlPolicy => ({ allowInsecureDev: config.allowInsecureDev });

const MAX_URL_LENGTH = 2048;

function isPrivateIPv4(host: string): boolean {
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const a = Number(m[1]);
  const b = Number(m[2]);
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) || // carrier-grade NAT
    (a === 169 && b === 254) || // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    a >= 224 // multicast / reserved
  );
}

function isPrivateIPv6(host: string): boolean {
  const h = host.replace(/^\[|\]$/g, '').toLowerCase();
  if (!h.includes(':')) return false;
  return (
    h === '::' ||
    h === '::1' ||
    /^f[cd]/.test(h) || // unique local fc00::/7
    /^fe[89ab]/.test(h) || // link-local fe80::/10
    h.startsWith('::ffff:') // IPv4-mapped (could hide a private IPv4)
  );
}

/** True for localhost, single-label names, internal suffixes and private IP literals. */
export function isBlockedHostname(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/\.$/, '');
  if (!h) return true;
  if (isPrivateIPv4(h) || isPrivateIPv6(h)) return true;
  if (!h.includes('.') && !h.includes(':')) return true;
  return /\.(localhost|local|internal|intranet|lan|home|corp|home\.arpa)$/.test(h);
}

/**
 * Parses and validates an absolute URL. Rejects non-HTTPS, credentials,
 * private/internal hosts and non-default ports (unless the dev policy is on).
 * The WHATWG URL parser normalises decimal/hex/octal IPv4 forms, so
 * `https://2130706433/` is seen as 127.0.0.1 and blocked.
 */
export function parseSafeUrl(input: string, policy: UrlPolicy = currentPolicy()): URL {
  if (typeof input !== 'string' || input.length === 0 || input.length > MAX_URL_LENGTH) {
    throw new SecurityError('URL is empty or too long.');
  }
  let url: URL;
  try {
    url = new URL(input);
  } catch {
    throw new SecurityError('Not a valid absolute URL.');
  }
  if (url.protocol !== 'https:' && !(policy.allowInsecureDev && url.protocol === 'http:')) {
    throw new SecurityError('Only HTTPS URLs are allowed.');
  }
  if (url.username || url.password) {
    throw new SecurityError('URLs containing credentials are not allowed.');
  }
  if (!policy.allowInsecureDev) {
    if (isBlockedHostname(url.hostname)) {
      throw new SecurityError('Private, local or internal network addresses are not allowed.');
    }
    if (url.port) {
      throw new SecurityError('Non-standard ports are not allowed.');
    }
  }
  return url;
}

export function isUrlAllowed(input: string, policy: UrlPolicy = currentPolicy()): boolean {
  try {
    parseSafeUrl(input, policy);
    return true;
  } catch {
    return false;
  }
}

/** A relative reference such as "../addons/x.json" (no scheme, not protocol-relative). */
export function isRelativeRef(value: string): boolean {
  return (
    value.length > 0 &&
    value.length <= MAX_URL_LENGTH &&
    !/^[a-z][a-z0-9+.-]*:/i.test(value) &&
    !value.startsWith('//') &&
    !value.includes('\\') &&
    !/[\u0000-\u001f]/.test(value)
  );
}

/** Resolves `ref` against `base` and re-validates the result. */
export function resolveUrl(ref: string, base: string, policy: UrlPolicy = currentPolicy()): string {
  let absolute: string;
  try {
    absolute = new URL(ref, base).href;
  } catch {
    throw new SecurityError('Could not resolve URL reference.');
  }
  return parseSafeUrl(absolute, policy).href;
}
