import { afterEach, describe, expect, it, vi } from 'vitest';
import sampleAddon from '../../public/addons/sample-addon.json';
import sampleRemote from '../../public/addons/sample-remote-addon.json';
import sampleRepo from '../../public/repo/sample-repository.json';
import { compareSemver } from '../lib/semver';
import {
  fetchAddonManifest,
  fetchRepository,
  parseAddonManifest,
  parseRepositoryManifest,
  RepositoryError,
} from './repositoryService';

const REPO_URL = 'https://example.com/repo/sample-repository.json';
const jsonResponse = (body: unknown, init: ResponseInit = {}) =>
  new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' }, ...init });

afterEach(() => vi.unstubAllGlobals());

describe('parseRepositoryManifest', () => {
  it('resolves relative manifest URLs against the repository URL', () => {
    const repo = parseRepositoryManifest(sampleRepo, REPO_URL);
    expect(repo.addons).toHaveLength(2);
    expect(repo.addons[0].manifestUrl).toBe('https://example.com/addons/sample-addon.json');
  });

  it('reports schema problems as RepositoryError with details', () => {
    try {
      parseRepositoryManifest({ schemaVersion: 2 }, REPO_URL);
      throw new Error('should have thrown');
    } catch (e) {
      expect(e).toBeInstanceOf(RepositoryError);
      expect((e as RepositoryError).details.length).toBeGreaterThan(0);
    }
  });

  it('rejects entries that resolve to an unsafe host', () => {
    const bad = { ...sampleRepo, addons: [{ ...sampleRepo.addons[0], manifestUrl: '//169.254.169.254/x.json' }] };
    expect(() => parseRepositoryManifest(bad, REPO_URL)).toThrow(RepositoryError);
  });
});

describe('parseAddonManifest', () => {
  it('resolves a relative catalogUrl against the manifest URL', () => {
    const m = parseAddonManifest(sampleRemote, 'https://example.com/addons/sample-remote-addon.json');
    expect(m.provider.kind === 'remote' && m.provider.catalogUrl).toBe('https://example.com/addons/sample-catalog.json');
  });

  it('refuses a relative catalogUrl for local files (no base URL)', () => {
    expect(() => parseAddonManifest(sampleRemote)).toThrow(RepositoryError);
  });

  it('accepts a valid static manifest', () => {
    expect(parseAddonManifest(sampleAddon).id).toBe('com.moviebox-plus.sample');
  });
});

describe('fetchRepository', () => {
  it('rejects non-HTTPS URLs without making a request', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    await expect(fetchRepository('http://example.com/r.json')).rejects.toThrow(/HTTPS/);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('rejects private hosts without making a request', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    await expect(fetchRepository('https://192.168.1.1/r.json')).rejects.toThrow(RepositoryError);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('fetches, validates and resolves a repository (no credentials, no redirects)', async () => {
    const fetchMock = vi.fn(async () => jsonResponse(sampleRepo));
    vi.stubGlobal('fetch', fetchMock);
    const repo = await fetchRepository(REPO_URL);
    expect(repo.manifest.name).toMatch(/sample/i);
    const init = (fetchMock.mock.calls[0] as unknown as [string, RequestInit])[1];
    expect(init.credentials).toBe('omit');
    expect(init.redirect).toBe('error');
  });

  it('shows a clear message for HTTP errors', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('nope', { status: 404 })));
    await expect(fetchRepository(REPO_URL)).rejects.toThrow(/HTTP 404/);
  });

  it('shows a clear message for network/CORS/redirect failures', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new TypeError('Failed to fetch'); }));
    await expect(fetchRepository(REPO_URL)).rejects.toThrow(/Network error/);
  });

  it('rejects non-JSON content types and invalid JSON', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('<html>', { headers: { 'content-type': 'text/html' } })));
    await expect(fetchRepository(REPO_URL)).rejects.toThrow(/content type/i);
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{oops', { headers: { 'content-type': 'application/json' } })));
    await expect(fetchRepository(REPO_URL)).rejects.toThrow(/not valid JSON/);
  });

  it('rejects oversized responses', async () => {
    const big = 'x'.repeat(600 * 1024);
    vi.stubGlobal('fetch', vi.fn(async () => new Response(big, { headers: { 'content-type': 'application/json' } })));
    await expect(fetchRepository(REPO_URL)).rejects.toThrow(/too large/);
  });
});

describe('fetchAddonManifest', () => {
  it('fetches and validates an add-on manifest', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => jsonResponse(sampleAddon)));
    const m = await fetchAddonManifest('https://example.com/addons/sample-addon.json');
    expect(m.version).toBe('1.0.0');
  });
});

describe('compareSemver', () => {
  it('orders versions', () => {
    expect(compareSemver('1.2.0', '1.1.9')).toBeGreaterThan(0);
    expect(compareSemver('1.0.0', '1.0.0')).toBe(0);
    expect(compareSemver('1.0.0-beta', '1.0.0')).toBeLessThan(0);
    expect(compareSemver('2.0.0', '10.0.0')).toBeLessThan(0);
  });
});
