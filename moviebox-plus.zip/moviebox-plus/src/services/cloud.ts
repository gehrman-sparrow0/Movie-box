import { supabase } from './supabase';

export async function fetchWatchlist(): Promise<string[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from('watchlist').select('item_id');
  if (error) throw new Error(error.message);
  return (data ?? []).map((r: { item_id: string }) => String(r.item_id));
}

export async function addWatchlist(userId: string, ids: string[]): Promise<void> {
  if (!supabase || ids.length === 0) return;
  const { error } = await supabase
    .from('watchlist')
    .upsert(ids.map((item_id) => ({ user_id: userId, item_id })), { onConflict: 'user_id,item_id' });
  if (error) throw new Error(error.message);
}

export async function removeWatchlist(userId: string, id: string): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.from('watchlist').delete().eq('user_id', userId).eq('item_id', id);
  if (error) throw new Error(error.message);
}
