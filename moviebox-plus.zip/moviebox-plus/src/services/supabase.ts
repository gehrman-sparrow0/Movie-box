import { createClient } from '@supabase/supabase-js';
import { config } from '../config';

/** null when Supabase is not configured; the app then works fully offline/local. */
export const supabase =
  config.supabaseUrl && config.supabaseAnonKey
    ? createClient(config.supabaseUrl, config.supabaseAnonKey, {
        // PKCE puts the auth code in the query string, which does not collide with HashRouter's #/routes.
        auth: { flowType: 'pkce', detectSessionInUrl: true, persistSession: true },
      })
    : null;
