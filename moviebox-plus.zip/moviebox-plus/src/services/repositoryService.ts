import { addonManifestSchema, formatIssues, repositoryManifestSchema } from '../schemas/addon';
import type { AddonManifest, ResolvedRepository } from '../types/addon';
import { FetchError, fetchJson, type FetchOptions } from '../lib/http';
import { isRelativeRef, parseSafeUrl, resolveUrl, SecurityError } from '../lib/security';

export class RepositoryError extends Error {
  readonly details: string[];
  constructor(message: string, details: string[] = []) {
    super(message);
    this.name = 'RepositoryError';
    this.details = details;
  }
}

function explain(e: unknown): string {
  if (e instanceof SecurityError || e instanceof FetchError) return e.message;
  return e instanceof Error ? e.message : 'Unknown error';
}

/** Validates repository JSON and resolves every add-on manifest URL against the repository URL. */
export function parseRepositoryManifest(data: unknown, repositoryUrl: string): ResolvedRepository {
  const parsed = repositoryManifestSchema.safeParse(data);
  if (!parsed.success) {
    throw new RepositoryError('This repository manifest is invalid.', formatIssues(parsed.error));
  }
  const addons = parsed.data.addons.map((entry) => {
    try {
      return { ...entry, manifestUrl: resolveUrl(entry.manifestUrl, repositoryUrl) };
    } catch (e) {
      throw new RepositoryError(`Add-on "${entry.id}" has an unsafe manifest URL.`, [explain(e)]);
    }
  });
  return { url: repositoryUrl, manifest: parsed.data, addons };
}

export async function fetchRepository(url: string, options: FetchOptions = {}): Promise<ResolvedRepository> {
  let safe: string;
  try {
    safe = parseSafeUrl(url.trim(), options.policy).href;
  } catch (e) {
    throw new RepositoryError(`This repository URL cannot be used. ${explain(e)}`);
  }
  let data: unknown;
  try {
    data = await fetchJson(safe, options);
  } catch (e) {
    throw new RepositoryError(`Could not load the repository. ${explain(e)}`);
  }
  return parseRepositoryManifest(data, safe);
}

/**
 * Validates an add-on manifest. A relative `catalogUrl` is resolved against `baseUrl`
 * (the URL the manifest was fetched from); local files must use absolute URLs.
 */
export function parseAddonManifest(data: unknown, baseUrl?: string): AddonManifest {
  const parsed = addonManifestSchema.safeParse(data);
  if (!parsed.success) {
    throw new RepositoryError('This add-on manifest is invalid.', formatIssues(parsed.error));
  }
  const manifest = parsed.data;
  if (manifest.provider.kind === 'remote' && isRelativeRef(manifest.provider.catalogUrl)) {
    if (!baseUrl) {
      throw new RepositoryError(
        'This add-on uses a relative catalogUrl, which cannot be resolved for a local file.',
        ['Use an absolute HTTPS catalogUrl.'],
      );
    }
    try {
      return {
        ...manifest,
        provider: { ...manifest.provider, catalogUrl: resolveUrl(manifest.provider.catalogUrl, baseUrl) },
      };
    } catch (e) {
      throw new RepositoryError('The add-on catalogUrl is unsafe.', [explain(e)]);
    }
  }
  return manifest;
}

export async function fetchAddonManifest(url: string, options: FetchOptions = {}): Promise<AddonManifest> {
  let safe: string;
  try {
    safe = parseSafeUrl(url, options.policy).href;
  } catch (e) {
    throw new RepositoryError(`This add-on URL cannot be used. ${explain(e)}`);
  }
  let data: unknown;
  try {
    data = await fetchJson(safe, options);
  } catch (e) {
    throw new RepositoryError(`Could not load the add-on manifest. ${explain(e)}`);
  }
  return parseAddonManifest(data, safe);
}
