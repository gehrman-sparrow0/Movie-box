import { z } from 'zod';
import { addonManifestSchema } from '../schemas/addon';
import type { InstalledAddon, RepositoryRecord } from '../types/addon';

const KEY = 'moviebox-plus:addons:v1';

export interface PersistedState {
  repositories: RepositoryRecord[];
  installed: InstalledAddon[];
}

const repositoryRecordSchema = z.object({
  url: z.string().max(2048),
  name: z.string().max(100),
  addedAt: z.string(),
});

const installedSchema = z.object({
  manifest: addonManifestSchema,
  enabled: z.boolean(),
  installedAt: z.string(),
  source: z.object({
    kind: z.enum(['repository', 'local']),
    repositoryUrl: z.string().max(2048).optional(),
    manifestUrl: z.string().max(2048).optional(),
  }),
});

const empty = (): PersistedState => ({ repositories: [], installed: [] });

/** Loads persisted add-on state, re-validating everything. Corrupt entries are dropped. */
export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return empty();
    const data = JSON.parse(raw) as { repositories?: unknown; installed?: unknown };
    const repositories = (Array.isArray(data.repositories) ? data.repositories : []).flatMap((r) => {
      const p = repositoryRecordSchema.safeParse(r);
      return p.success ? [p.data] : [];
    });
    const installed = (Array.isArray(data.installed) ? data.installed : []).flatMap((a) => {
      const p = installedSchema.safeParse(a);
      return p.success ? [p.data] : [];
    });
    return { repositories, installed };
  } catch {
    return empty();
  }
}

export function saveState(state: PersistedState): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage full or unavailable (private mode) */
  }
}
