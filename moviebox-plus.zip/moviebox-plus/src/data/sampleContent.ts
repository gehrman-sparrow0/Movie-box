import type { ContentItem, StreamSource } from '../types/content';

/*
 * Sample data. Movies marked as Blender Foundation films use their openly licensed (CC BY 3.0) demo
 * files; every other title is a fictional placeholder that plays a generic demo clip.
 */
const BUCKET = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/';
const mp4 = (file: string, label = 'MP4 (demo)'): StreamSource => ({ url: `${BUCKET}${file}`, type: 'mp4', label });
const HLS_DEMO: StreamSource = {
  url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  type: 'hls',
  label: 'HLS (demo)',
};

function poster(title: string, h1: number, h2: number): string {
  const safe = title.replace(/[&<>"']/g, '').slice(0, 22);
  const svg =
    `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='450' viewBox='0 0 300 450'>` +
    `<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>` +
    `<stop offset='0' stop-color='hsl(${h1} 55% 38%)'/><stop offset='1' stop-color='hsl(${h2} 60% 12%)'/></linearGradient></defs>` +
    `<rect width='300' height='450' fill='url(#g)'/>` +
    `<circle cx='235' cy='95' r='70' fill='white' fill-opacity='.07'/>` +
    `<circle cx='60' cy='300' r='110' fill='black' fill-opacity='.12'/>` +
    `<text x='22' y='410' font-family='Georgia,serif' font-size='27' font-weight='700' fill='white'>${safe}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const clips = [
  'ForBiggerBlazes.mp4',
  'ForBiggerEscapes.mp4',
  'ForBiggerJoyrides.mp4',
  'ForBiggerMeltdowns.mp4',
  'ForBiggerFun.mp4',
];

function episodes(count: number, offset = 0) {
  return Array.from({ length: count }, (_, i) => ({
    number: i + 1,
    title: `Episode ${i + 1}`,
    sources: [mp4(clips[(i + offset) % clips.length])],
  }));
}

export const sampleContent: ContentItem[] = [
  {
    id: 'big-buck-bunny',
    title: 'Big Buck Bunny',
    type: 'movie',
    year: 2008,
    rating: 7.6,
    genres: ['Animation', 'Comedy', 'Family'],
    synopsis:
      'A gentle giant rabbit is pushed too far by three rowdy rodents and plans an elaborate, cartoonish comeback. An open movie by the Blender Foundation.',
    durationMinutes: 10,
    poster: poster('Big Buck Bunny', 95, 160),
    sources: [mp4('BigBuckBunny.mp4'), HLS_DEMO],
  },
  {
    id: 'sintel',
    title: 'Sintel',
    type: 'movie',
    year: 2010,
    rating: 7.4,
    genres: ['Fantasy', 'Adventure', 'Animation'],
    synopsis:
      'A lone wanderer searches a harsh world for the dragon she once befriended. An open movie by the Blender Foundation.',
    durationMinutes: 15,
    poster: poster('Sintel', 15, 340),
    sources: [mp4('Sintel.mp4')],
  },
  {
    id: 'tears-of-steel',
    title: 'Tears of Steel',
    type: 'movie',
    year: 2012,
    rating: 6.9,
    genres: ['Sci-Fi', 'Action'],
    synopsis:
      'A group of warriors and scientists try to save the world from destructive robots in a future Amsterdam. An open movie by the Blender Foundation.',
    durationMinutes: 12,
    poster: poster('Tears of Steel', 200, 250),
    sources: [mp4('TearsOfSteel.mp4')],
  },
  {
    id: 'elephants-dream',
    title: 'Elephants Dream',
    type: 'movie',
    year: 2006,
    rating: 6.2,
    genres: ['Sci-Fi', 'Animation'],
    synopsis: 'Two strangers explore a surreal mechanical world. The first open movie by the Blender Foundation.',
    durationMinutes: 11,
    poster: poster('Elephants Dream', 40, 10),
    sources: [mp4('ElephantsDream.mp4')],
  },
  {
    id: 'midnight-harbor',
    title: 'Midnight Harbor',
    type: 'movie',
    year: 2023,
    rating: 8.1,
    genres: ['Thriller', 'Drama'],
    synopsis: 'A night-shift dockworker finds a ledger that names everyone on the waterfront. (Fictional sample entry.)',
    durationMinutes: 118,
    poster: poster('Midnight Harbor', 210, 230),
    sources: [mp4('ForBiggerBlazes.mp4')],
  },
  {
    id: 'solar-drift',
    title: 'Solar Drift',
    type: 'movie',
    year: 2024,
    rating: 7.8,
    genres: ['Sci-Fi', 'Adventure'],
    synopsis: 'A salvage crew rides a dying star’s solar wind to reach a derelict ark. (Fictional sample entry.)',
    durationMinutes: 126,
    poster: poster('Solar Drift', 28, 280),
    sources: [mp4('ForBiggerEscapes.mp4')],
  },
  {
    id: 'paper-lanterns',
    title: 'Paper Lanterns',
    type: 'movie',
    year: 2021,
    rating: 7.2,
    genres: ['Romance', 'Drama'],
    synopsis: 'Two translators trade letters across a river festival that only happens once a decade. (Fictional sample entry.)',
    durationMinutes: 104,
    poster: poster('Paper Lanterns', 350, 20),
    sources: [mp4('ForBiggerJoyrides.mp4')],
  },
  {
    id: 'neon-kitsune',
    title: 'Neon Kitsune',
    type: 'anime',
    year: 2024,
    rating: 8.6,
    genres: ['Action', 'Fantasy', 'Mystery'],
    synopsis: 'A fox spirit runs a ramen stall by day and hunts rogue lantern ghosts through the city by night. (Fictional sample entry.)',
    poster: poster('Neon Kitsune', 310, 200),
    sources: [],
    episodes: episodes(4, 0),
  },
  {
    id: 'skyward-academy',
    title: 'Skyward Academy',
    type: 'anime',
    year: 2022,
    rating: 7.9,
    genres: ['Adventure', 'Slice of Life'],
    synopsis: 'First-years at a floating school learn to pilot wind-gliders before the monsoon season. (Fictional sample entry.)',
    poster: poster('Skyward Academy', 190, 220),
    sources: [],
    episodes: episodes(3, 1),
  },
  {
    id: 'tidewalker',
    title: 'Blade of the Tidewalker',
    type: 'anime',
    year: 2020,
    rating: 8.3,
    genres: ['Action', 'Drama'],
    synopsis: 'A swordswoman can only fight when the tide is in, and the moon is bargaining. (Fictional sample entry.)',
    poster: poster('Blade of the Tidewalker', 170, 260),
    sources: [],
    episodes: episodes(5, 2),
  },
  {
    id: 'cloudkeeper',
    title: 'Cloudkeeper Chronicles',
    type: 'anime',
    year: 2019,
    rating: 7.5,
    genres: ['Slice of Life', 'Fantasy'],
    synopsis: 'A quiet weather-keeper tends the sky over a mountain village and the secrets stored in its storms. (Fictional sample entry.)',
    poster: poster('Cloudkeeper Chronicles', 60, 150),
    sources: [],
    episodes: episodes(3, 3),
  },
];
