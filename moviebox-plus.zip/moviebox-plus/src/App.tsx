import { Navigate, Route, Routes } from 'react-router-dom';
import AppShell from './components/AppShell';
import AddonsPage from './pages/AddonsPage';
import BrowsePage from './pages/BrowsePage';
import DetailsPage from './pages/DetailsPage';
import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import SettingsPage from './pages/SettingsPage';
import WatchlistPage from './pages/WatchlistPage';
import WatchPage from './pages/WatchPage';

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<HomePage />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="movies" element={<BrowsePage type="movie" />} />
        <Route path="anime" element={<BrowsePage type="anime" />} />
        <Route path="watchlist" element={<WatchlistPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="settings/addons" element={<AddonsPage />} />
        <Route path="title/:id" element={<DetailsPage />} />
        <Route path="watch/:id" element={<WatchPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
