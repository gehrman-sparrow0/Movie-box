import { useMemo, useState } from 'react';
import { Search, SearchX } from 'lucide-react';
import EmptyState from '../components/EmptyState';
import FilterChips from '../components/FilterChips';
import PosterCard from '../components/PosterCard';
import { GridSkeleton } from '../components/Skeleton';
import { useCatalog } from '../hooks/useCatalog';

type TypeFilter = 'all' | 'movie' | 'anime';

export default function SearchPage() {
  const { items, loading } = useCatalog();
  const [query, setQuery] = useState('');
  const [type, setType] = useState<TypeFilter>('all');
  const [genre, setGenre] = useState('All');

  const genres = useMemo(() => ['All', ...Array.from(new Set(items.flatMap((i) => i.genres))).sort()], [items]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter(
      (i) =>
        (type === 'all' || i.type === type) &&
        (genre === 'All' || i.genres.includes(genre)) &&
        (q === '' ||
          i.title.toLowerCase().includes(q) ||
          i.genres.some((g) => g.toLowerCase().includes(q)) ||
          String(i.year) === q),
    );
  }, [items, query, type, genre]);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">Search</h1>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" aria-hidden />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Title, genre or year"
          aria-label="Search titles"
          className="input pl-10"
          autoFocus
        />
      </div>
      <FilterChips
        label="Type"
        value={type}
        onChange={setType}
        options={[
          { value: 'all', label: 'All' },
          { value: 'movie', label: 'Movies' },
          { value: 'anime', label: 'Anime' },
        ]}
      />
      <FilterChips
        label="Genre"
        value={genre}
        onChange={setGenre}
        options={genres.map((g) => ({ value: g, label: g }))}
      />

      {loading && items.length === 0 ? (
        <GridSkeleton />
      ) : results.length === 0 ? (
        <EmptyState
          icon={<SearchX className="h-6 w-6" />}
          title="Nothing found"
          description={`No titles match “${query}”. Check the spelling or clear a filter.`}
        />
      ) : (
        <>
          <p className="text-sm text-slate-400" aria-live="polite">
            {results.length} {results.length === 1 ? 'title' : 'titles'}
          </p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {results.map((item) => (
              <PosterCard key={item.id} item={item} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
