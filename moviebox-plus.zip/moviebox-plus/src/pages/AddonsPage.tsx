import { useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Check, Download, FileJson, Loader2, Plus, RefreshCw, Trash2 } from 'lucide-react';
import EmptyState from '../components/EmptyState';
import ErrorBanner from '../components/ErrorBanner';
import { config } from '../config';
import { useAddons } from '../hooks/useAddons';
import { useAsyncAction } from '../hooks/useAsyncAction';
import type { RepositoryEntry } from '../types/addon';

function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? 'bg-accent' : 'bg-surface2'}`}
    >
      <span
        className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
          checked ? 'translate-x-5' : ''
        }`}
      />
    </button>
  );
}

const RIGHTS_PROMPT = (name: string, rights?: string) =>
  `Install “${name}”?\n\nOnly install add-ons that provide content you are authorized to access.` +
  (rights ? `\n\nThe add-on states: ${rights}` : '');

export default function AddonsPage() {
  const addons = useAddons();
  const { run, busy, error, notice, clearError } = useAsyncAction();
  const [repoUrl, setRepoUrl] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const sampleUrl = `${window.location.origin}${import.meta.env.BASE_URL}repo/sample-repository.json`;
  const installedIds = new Set(addons.installed.map((a) => a.manifest.id));

  const addRepo = (e: FormEvent) => {
    e.preventDefault();
    run('add-repo', async () => {
      await addons.addRepository(repoUrl);
      setRepoUrl('');
      return 'Repository added.';
    });
  };

  const install = (repositoryUrl: string, entry: RepositoryEntry) => {
    if (!window.confirm(RIGHTS_PROMPT(entry.name))) return;
    run(`install:${entry.id}`, async () => {
      await addons.installFromRepository(repositoryUrl, entry);
      return `${entry.name} installed.`;
    });
  };

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div>
        <Link to="/settings" className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200">
          <ArrowLeft className="h-4 w-4" aria-hidden /> Settings
        </Link>
        <h1 className="mt-2 text-3xl font-semibold">Add-ons</h1>
        <p className="mt-1 text-sm text-slate-400">
          Add-ons describe catalogs and streaming sources as JSON. They never run code on your device.
        </p>
      </div>

      {error && <ErrorBanner title={error.message} details={error.details} onDismiss={clearError} />}
      {notice && (
        <p role="status" className="rounded-xl bg-sea/10 px-3.5 py-2.5 text-sm text-sea">
          {notice}
        </p>
      )}

      <section className="space-y-3" aria-labelledby="repos-h">
        <h2 id="repos-h" className="text-xl font-semibold">
          Repositories
        </h2>
        <form onSubmit={addRepo} className="card space-y-3">
          <label className="block text-sm font-medium" htmlFor="repo-url">
            Repository URL
          </label>
          <div className="flex gap-2">
            <input
              id="repo-url"
              className="input"
              inputMode="url"
              placeholder="https://example.com/repository.json"
              value={repoUrl}
              onChange={(e) => setRepoUrl(e.target.value)}
              required
            />
            <button className="btn btn-primary shrink-0" disabled={busy === 'add-repo'}>
              {busy === 'add-repo' ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Plus className="h-4 w-4" aria-hidden />
              )}
              Add
            </button>
          </div>
          <button type="button" className="text-sm text-accent hover:underline" onClick={() => setRepoUrl(sampleUrl)}>
            Use the sample repository
          </button>
          {sampleUrl.startsWith('http://') && !config.allowInsecureDev && (
            <p className="text-xs text-slate-500">
              The sample repository is served over HTTP here, so it needs VITE_ALLOW_INSECURE_DEV=true in development.
            </p>
          )}
        </form>

        {addons.repositories.length === 0 ? (
          <EmptyState
            icon={<Download className="h-6 w-6" />}
            title="No repositories yet"
            description="Add a repository URL to browse the add-ons it offers."
          />
        ) : (
          addons.repositories.map((repo) => {
            const st = addons.repoStatus[repo.url];
            return (
              <div key={repo.url} className="card space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate font-sans font-semibold">{st?.data?.manifest.name ?? repo.name}</h3>
                    <p className="truncate text-xs text-slate-500">{repo.url}</p>
                  </div>
                  <div className="flex shrink-0 gap-1.5">
                    <button
                      className="btn btn-ghost !px-3"
                      aria-label={`Refresh ${repo.name}`}
                      onClick={() => run(`refresh:${repo.url}`, () => addons.refreshRepository(repo.url))}
                    >
                      <RefreshCw className={`h-4 w-4 ${st?.status === 'loading' ? 'animate-spin' : ''}`} aria-hidden />
                    </button>
                    <button
                      className="btn btn-danger !px-3"
                      aria-label={`Remove ${repo.name}`}
                      onClick={() => window.confirm(`Remove repository “${repo.name}”? Installed add-ons stay installed.`) && addons.removeRepository(repo.url)}
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                    </button>
                  </div>
                </div>

                {st?.status === 'error' && <ErrorBanner title={st.error ?? 'Repository error'} details={st.details} />}
                {st?.status === 'loading' && !st.data && <p className="text-sm text-slate-400">Loading…</p>}

                {st?.data && st.data.addons.length === 0 && (
                  <p className="text-sm text-slate-400">This repository does not list any add-ons.</p>
                )}
                <ul className="space-y-2">
                  {st?.data?.addons.map((entry) => (
                    <li key={entry.id} className="flex items-center gap-3 rounded-xl bg-surface2 p-3">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium">
                          {entry.name} <span className="font-normal text-slate-500">{entry.version}</span>
                        </p>
                        <p className="line-clamp-2 text-sm text-slate-400">{entry.description}</p>
                        <p className="mt-1 text-xs text-slate-500">{entry.types.join(' and ')}</p>
                      </div>
                      {installedIds.has(entry.id) ? (
                        <span className="inline-flex items-center gap-1 text-sm text-sea">
                          <Check className="h-4 w-4" aria-hidden /> Installed
                        </span>
                      ) : (
                        <button
                          className="btn btn-primary"
                          disabled={busy === `install:${entry.id}`}
                          onClick={() => install(repo.url, entry)}
                        >
                          {busy === `install:${entry.id}` ? (
                            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                          ) : (
                            <Download className="h-4 w-4" aria-hidden />
                          )}
                          Install
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })
        )}
      </section>

      <section className="space-y-3" aria-labelledby="installed-h">
        <h2 id="installed-h" className="text-xl font-semibold">
          Installed
        </h2>
        {addons.installed.length === 0 ? (
          <EmptyState
            icon={<Download className="h-6 w-6" />}
            title="Nothing installed"
            description="Install an add-on from a repository, or import a manifest file below."
          />
        ) : (
          addons.installed.map((a) => {
            const m = a.manifest;
            const update = addons.getUpdate(m.id);
            return (
              <div key={m.id} className={`card space-y-3 ${a.enabled ? '' : 'opacity-70'}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="font-sans font-semibold">
                      {m.name} <span className="font-normal text-slate-500">{m.version}</span>
                    </h3>
                    <p className="text-sm text-slate-400">{m.description}</p>
                  </div>
                  <Switch
                    checked={a.enabled}
                    onChange={(v) => addons.setEnabled(m.id, v)}
                    label={`${a.enabled ? 'Disable' : 'Enable'} ${m.name}`}
                  />
                </div>
                <p className="text-xs text-slate-500">
                  By {m.author}, {m.types.join(' and ')}, {m.provider.kind === 'remote' ? 'remote catalog' : 'bundled catalog'},{' '}
                  {a.source.kind === 'local' ? 'imported from a file' : 'from a repository'}
                </p>
                <details className="text-sm text-slate-400">
                  <summary className="cursor-pointer text-slate-300">Content rights statement</summary>
                  <p className="mt-1.5">{m.contentRights}</p>
                </details>
                <div className="flex flex-wrap gap-2">
                  {a.source.kind === 'repository' && (
                    <button
                      className={`btn ${update ? 'btn-primary' : 'btn-ghost'}`}
                      disabled={busy === `update:${m.id}`}
                      onClick={() =>
                        run(`update:${m.id}`, async () =>
                          (await addons.updateAddon(m.id)) === 'updated' ? `${m.name} updated.` : `${m.name} is up to date.`,
                        )
                      }
                    >
                      {busy === `update:${m.id}` ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <RefreshCw className="h-4 w-4" aria-hidden />
                      )}
                      {update ? `Update to ${update.version}` : 'Check for updates'}
                    </button>
                  )}
                  <button
                    className="btn btn-danger"
                    onClick={() => window.confirm(`Uninstall “${m.name}”?`) && addons.uninstall(m.id)}
                  >
                    <Trash2 className="h-4 w-4" aria-hidden /> Uninstall
                  </button>
                </div>
              </div>
            );
          })
        )}
      </section>

      <section className="card space-y-3" aria-labelledby="import-h">
        <h2 id="import-h" className="text-xl font-semibold">
          Import from file
        </h2>
        <p className="text-sm text-slate-400">
          Choose an add-on manifest (.json). It is checked against the strict schema before anything is saved.
        </p>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (fileRef.current) fileRef.current.value = '';
            if (!file) return;
            if (!window.confirm(RIGHTS_PROMPT(file.name))) return;
            run('import', async () => {
              await addons.importLocalManifest(file);
              return 'Add-on imported.';
            });
          }}
        />
        <button className="btn btn-ghost" disabled={busy === 'import'} onClick={() => fileRef.current?.click()}>
          <FileJson className="h-4 w-4" aria-hidden /> Choose manifest file
        </button>
      </section>
    </div>
  );
}
