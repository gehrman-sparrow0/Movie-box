import { Link } from 'react-router-dom';
import { Bookmark } from 'lucide-react';
import EmptyState from '../components/EmptyState';
import ErrorBanner from '../components/ErrorBanner';
import PosterCard from '../components/PosterCard';
import { GridSkeleton } from '../components/Skeleton';
import { useCatalog } from '../hooks/useCatalog';
import { useWatchlist } from '../hooks/useWatchlist';

export default function WatchlistPage() {
  const { items, loading } = useCatalog();
  const { ids, syncError } = useWatchlist();
  const saved = items.filter((i) => ids.includes(i.id));
  const hidden = ids.length - saved.length;

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">Watchlist</h1>
      {syncError && <ErrorBanner title="Cloud sync problem" details={[syncError]} />}
      {loading && items.length === 0 ? (
        <GridSkeleton count={6} />
      ) : saved.length === 0 ? (
        <EmptyState
          icon={<Bookmark className="h-6 w-6" />}
          title="Your watchlist is empty"
          description="Save a title from its details page and it will show up here."
          action={
            <Link to="/movies" className="btn btn-primary">
              Browse movies
            </Link>
          }
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {saved.map((item) => (
              <PosterCard key={item.id} item={item} />
            ))}
          </div>
          {hidden > 0 && (
            <p className="text-sm text-slate-400">
              {hidden} saved {hidden === 1 ? 'title is' : 'titles are'} hidden because the add-on that provides{' '}
              {hidden === 1 ? 'it is' : 'them are'} disabled or removed.
            </p>
          )}
        </>
      )}
    </div>
  );
}
