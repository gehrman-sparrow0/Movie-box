import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, LogOut, Mail, Puzzle, ShieldCheck } from 'lucide-react';
import ErrorBanner from '../components/ErrorBanner';
import { config } from '../config';
import { useAddons } from '../hooks/useAddons';
import { useAsyncAction } from '../hooks/useAsyncAction';
import { useAuth } from '../hooks/useAuth';

function AccountCard() {
  const { enabled, user, signInWithEmail, signOut } = useAuth();
  const [email, setEmail] = useState('');
  const { run, busy, error, notice, clearError } = useAsyncAction();

  const submit = (e: FormEvent) => {
    e.preventDefault();
    run('signin', async () => {
      await signInWithEmail(email.trim());
      return 'Check your inbox for the sign-in link.';
    });
  };

  return (
    <section className="card space-y-3">
      <h2 className="text-lg font-semibold">Account and cloud sync</h2>
      {!enabled ? (
        <p className="text-sm text-slate-400">
          Cloud sync is off. Your watchlist and add-ons are stored on this device. To enable accounts, set
          VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY (see the README).
        </p>
      ) : user ? (
        <div className="flex items-center justify-between gap-3">
          <p className="min-w-0 truncate text-sm text-slate-300">Signed in as {user.email}</p>
          <button className="btn btn-ghost" onClick={() => signOut()}>
            <LogOut className="h-4 w-4" aria-hidden /> Sign out
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-3">
          <p className="text-sm text-slate-400">Sign in with an email link to sync your watchlist across devices.</p>
          <div className="flex gap-2">
            <input
              className="input"
              type="email"
              required
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-label="Email address"
            />
            <button className="btn btn-primary shrink-0" disabled={busy === 'signin'}>
              <Mail className="h-4 w-4" aria-hidden /> Send link
            </button>
          </div>
        </form>
      )}
      {error && <ErrorBanner title={error.message} onDismiss={clearError} />}
      {notice && <p className="text-sm text-sea">{notice}</p>}
    </section>
  );
}

export default function SettingsPage() {
  const { installed } = useAddons();
  const enabledCount = installed.filter((a) => a.enabled).length;

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-3xl font-semibold">Settings</h1>

      <Link to="/settings/addons" className="card flex items-center gap-4 transition hover:border-accent/40">
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-surface2 text-accent">
          <Puzzle className="h-5 w-5" aria-hidden />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-medium">Add-ons and repositories</span>
          <span className="block text-sm text-slate-400">
            {installed.length === 0
              ? 'Add a repository to install your first add-on'
              : `${installed.length} installed, ${enabledCount} enabled`}
          </span>
        </span>
        <ChevronRight className="h-5 w-5 text-slate-500" aria-hidden />
      </Link>

      <AccountCard />

      <section className="card space-y-2">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <ShieldCheck className="h-5 w-5 text-sea" aria-hidden /> Security
        </h2>
        <ul className="list-disc space-y-1 pl-5 text-sm text-slate-400">
          <li>Add-ons are JSON only. No add-on code is ever executed.</li>
          <li>Repositories and media must use public HTTPS URLs. Redirects and credentials are refused.</li>
          <li>Only install add-ons for content you are authorized to access.</li>
        </ul>
        {config.allowInsecureDev && (
          <p className="rounded-lg bg-accent/10 px-3 py-2 text-sm text-accent">
            Development mode: http:// and localhost URLs are allowed. This is never active in production builds.
          </p>
        )}
      </section>

      <p className="text-center text-xs text-slate-500">MovieBox Plus 1.0.0</p>
    </div>
  );
}
