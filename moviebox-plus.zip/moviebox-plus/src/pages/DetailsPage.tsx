import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Bookmark, BookmarkCheck, Play, Puzzle, Star } from 'lucide-react';
import ContentRow from '../components/ContentRow';
import EmptyState from '../components/EmptyState';
import Poster from '../components/Poster';
import { Skeleton } from '../components/Skeleton';
import { useCatalog } from '../hooks/useCatalog';
import { useWatchlist } from '../hooks/useWatchlist';

export default function DetailsPage() {
  const { id = '' } = useParams();
  const { items, loading } = useCatalog();
  const { has, toggle } = useWatchlist();
  const item = items.find((i) => i.id === id);

  if (!item) {
    return loading ? (
      <div className="flex gap-5" aria-busy="true">
        <Skeleton className="h-64 w-44 shrink-0" />
        <div className="flex-1 space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    ) : (
      <EmptyState
        icon={<Puzzle className="h-6 w-6" />}
        title="Title not found"
        description="It may belong to an add-on that is disabled or uninstalled."
        action={
          <Link to="/" className="btn btn-primary">
            Back to home
          </Link>
        }
      />
    );
  }

  const encoded = encodeURIComponent(item.id);
  const saved = has(item.id);
  const playable = item.sources.length > 0 || (item.episodes ?? []).some((e) => e.sources.length > 0);
  const related = items
    .filter((i) => i.id !== item.id && i.type === item.type && i.genres.some((g) => item.genres.includes(g)))
    .slice(0, 10);

  return (
    <div className="space-y-8">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200">
        <ArrowLeft className="h-4 w-4" aria-hidden /> Back
      </Link>

      <section className="flex flex-col gap-6 sm:flex-row">
        <Poster
          src={item.poster}
          title={item.title}
          className="mx-auto aspect-[2/3] w-44 shrink-0 rounded-2xl ring-1 ring-white/10 sm:mx-0 sm:w-56"
        />
        <div className="min-w-0 space-y-4">
          <div>
            <h1 className="text-3xl font-semibold md:text-4xl">{item.title}</h1>
            <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-300">
              <span className="inline-flex items-center gap-1 text-accent">
                <Star className="h-4 w-4 fill-current" aria-hidden />
                {item.rating.toFixed(1)}
              </span>
              <span>{item.year}</span>
              {item.durationMinutes && <span>{item.durationMinutes} min</span>}
              <span>{item.type === 'anime' ? 'Anime' : 'Movie'}</span>
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {item.genres.map((g) => (
              <span key={g} className="rounded-full bg-white/5 px-3 py-1 text-xs text-slate-300">
                {g}
              </span>
            ))}
          </div>
          <p className="max-w-2xl leading-relaxed text-slate-300">{item.synopsis}</p>
          <div className="flex flex-wrap gap-2.5">
            {playable ? (
              <Link to={`/watch/${encoded}`} className="btn btn-primary">
                <Play className="h-4 w-4 fill-current" aria-hidden /> Play
              </Link>
            ) : (
              <button className="btn btn-ghost" disabled>
                No sources available
              </button>
            )}
            <button onClick={() => toggle(item.id)} className="btn btn-ghost" aria-pressed={saved}>
              {saved ? (
                <BookmarkCheck className="h-4 w-4 text-accent" aria-hidden />
              ) : (
                <Bookmark className="h-4 w-4" aria-hidden />
              )}
              {saved ? 'Saved to watchlist' : 'Add to watchlist'}
            </button>
          </div>
          <p className="text-xs text-slate-500">Provided by {item.originName}</p>
        </div>
      </section>

      {item.episodes && item.episodes.length > 0 && (
        <section>
          <h2 className="mb-3 text-xl font-semibold">Episodes</h2>
          <ul className="divide-y divide-white/5 overflow-hidden rounded-2xl border border-white/5 bg-surface">
            {item.episodes.map((ep) => (
              <li key={ep.number}>
                <Link
                  to={`/watch/${encoded}?ep=${ep.number}`}
                  className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-white/5"
                >
                  <span className="truncate">
                    <span className="mr-3 text-slate-500">{ep.number}</span>
                    {ep.title}
                  </span>
                  <Play className="h-4 w-4 shrink-0 text-accent" aria-label="Play" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      <ContentRow title="More like this" items={related} />
    </div>
  );
}
