import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import EmptyState from '../components/EmptyState';
import ErrorBanner from '../components/ErrorBanner';
import { Skeleton } from '../components/Skeleton';
import VideoPlayer from '../components/VideoPlayer';
import { useCatalog } from '../hooks/useCatalog';
import type { StreamSource } from '../types/content';

export default function WatchPage() {
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  const { items, loading, getProvider } = useCatalog();
  const item = items.find((i) => i.id === id);

  const episodes = item?.episodes ?? [];
  const requested = Number(params.get('ep'));
  const episode = episodes.length
    ? (episodes.find((e) => e.number === requested) ?? episodes[0])
    : undefined;

  const [sources, setSources] = useState<StreamSource[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!item) return;
    let cancelled = false;
    setSources(null);
    setError(null);
    const provider = getProvider(item.origin);
    (provider ? provider.getSources(item, episode?.number) : Promise.resolve<StreamSource[]>([]))
      .then((s) => !cancelled && setSources(s))
      .catch((e) => !cancelled && setError(e instanceof Error ? e.message : 'Could not load sources.'));
    return () => {
      cancelled = true;
    };
  }, [item, episode?.number, getProvider]);

  if (!item) {
    return loading ? (
      <Skeleton className="aspect-video w-full" />
    ) : (
      <EmptyState
        icon={<ArrowLeft className="h-6 w-6" />}
        title="Nothing to play"
        description="This title is unavailable. Its add-on may be disabled."
        action={
          <Link to="/" className="btn btn-primary">
            Back to home
          </Link>
        }
      />
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <Link
        to={`/title/${encodeURIComponent(item.id)}`}
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden /> {item.title}
      </Link>

      {error && <ErrorBanner title="Sources could not be loaded" details={[error]} />}
      {sources === null && !error ? (
        <Skeleton className="aspect-video w-full" />
      ) : (
        <VideoPlayer
          sources={sources ?? []}
          title={episode ? `${item.title}, episode ${episode.number}` : item.title}
          poster={item.poster}
        />
      )}

      <div>
        <h1 className="text-2xl font-semibold">{item.title}</h1>
        {episode && <p className="mt-1 text-slate-400">{`Episode ${episode.number}: ${episode.title}`}</p>}
      </div>

      {episodes.length > 1 && (
        <section>
          <h2 className="mb-3 text-lg font-semibold">Episodes</h2>
          <div className="flex flex-wrap gap-2">
            {episodes.map((e) => (
              <Link
                key={e.number}
                to={`/watch/${encodeURIComponent(item.id)}?ep=${e.number}`}
                replace
                className={`chip ${e.number === episode?.number ? 'chip-active' : ''}`}
                aria-current={e.number === episode?.number ? 'true' : undefined}
              >
                {e.number}
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
