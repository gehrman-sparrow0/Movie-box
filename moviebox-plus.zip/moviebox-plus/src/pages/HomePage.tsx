import { useMemo } from 'react';
import ContentRow from '../components/ContentRow';
import ErrorBanner from '../components/ErrorBanner';
import Hero from '../components/Hero';
import { RowSkeleton, Skeleton } from '../components/Skeleton';
import { useCatalog } from '../hooks/useCatalog';

export default function HomePage() {
  const { items, loading, errors } = useCatalog();

  const byRating = useMemo(() => [...items].sort((a, b) => b.rating - a.rating), [items]);
  const newest = useMemo(() => [...items].sort((a, b) => b.year - a.year).slice(0, 12), [items]);

  if (loading && items.length === 0) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-72 w-full rounded-3xl md:h-96" />
        <RowSkeleton />
        <RowSkeleton />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {errors.map((e) => (
        <ErrorBanner key={e.addonId} title={`“${e.name}” could not load its catalog`} details={[e.message]} />
      ))}
      {byRating[0] && <Hero item={byRating[0]} />}
      <ContentRow title="Top rated" items={byRating.slice(0, 12)} />
      <ContentRow title="Newest releases" items={newest} />
      <ContentRow title="Movies" items={items.filter((i) => i.type === 'movie')} />
      <ContentRow title="Anime" items={items.filter((i) => i.type === 'anime')} />
    </div>
  );
}
