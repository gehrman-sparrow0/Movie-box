import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Puzzle } from 'lucide-react';
import EmptyState from '../components/EmptyState';
import FilterChips from '../components/FilterChips';
import { GridSkeleton } from '../components/Skeleton';
import PosterCard from '../components/PosterCard';
import { useCatalog } from '../hooks/useCatalog';
import type { ContentType } from '../types/content';

type Sort = 'rating' | 'year' | 'title';

export default function BrowsePage({ type }: { type: ContentType }) {
  const { items, loading } = useCatalog();
  const [genre, setGenre] = useState('All');
  const [sort, setSort] = useState<Sort>('rating');

  const ofType = useMemo(() => items.filter((i) => i.type === type), [items, type]);
  const genres = useMemo(
    () => ['All', ...Array.from(new Set(ofType.flatMap((i) => i.genres))).sort()],
    [ofType],
  );
  const shown = useMemo(() => {
    const list = genre === 'All' ? ofType : ofType.filter((i) => i.genres.includes(genre));
    return [...list].sort((a, b) =>
      sort === 'title' ? a.title.localeCompare(b.title) : sort === 'year' ? b.year - a.year : b.rating - a.rating,
    );
  }, [ofType, genre, sort]);

  const heading = type === 'movie' ? 'Movies' : 'Anime';

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-3">
        <h1 className="text-3xl font-semibold">{heading}</h1>
        <label className="flex items-center gap-2 text-sm text-slate-400">
          Sort by
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            className="rounded-lg border border-white/10 bg-surface2 px-2 py-1.5 text-slate-100"
          >
            <option value="rating">Rating</option>
            <option value="year">Newest</option>
            <option value="title">Title</option>
          </select>
        </label>
      </div>

      {genres.length > 2 && (
        <FilterChips
          label="Genre"
          value={genre}
          onChange={setGenre}
          options={genres.map((g) => ({ value: g, label: g }))}
        />
      )}

      {loading && items.length === 0 ? (
        <GridSkeleton />
      ) : shown.length === 0 ? (
        <EmptyState
          icon={<Puzzle className="h-6 w-6" />}
          title={`No ${heading.toLowerCase()} match`}
          description="Try another genre, or enable an add-on that provides more titles."
          action={
            <Link to="/settings/addons" className="btn btn-primary">
              Manage add-ons
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {shown.map((item) => (
            <PosterCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}
