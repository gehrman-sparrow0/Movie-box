import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import { AddonsProvider } from './hooks/useAddons';
import { AuthProvider } from './hooks/useAuth';
import { CatalogProvider } from './hooks/useCatalog';
import { WatchlistProvider } from './hooks/useWatchlist';
import './index.css';

// HashRouter keeps routing client-side, so static hosts such as GitHub Pages need no rewrite rules.
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HashRouter>
      <AuthProvider>
        <AddonsProvider>
          <CatalogProvider>
            <WatchlistProvider>
              <App />
            </WatchlistProvider>
          </CatalogProvider>
        </AddonsProvider>
      </AuthProvider>
    </HashRouter>
  </React.StrictMode>,
);
