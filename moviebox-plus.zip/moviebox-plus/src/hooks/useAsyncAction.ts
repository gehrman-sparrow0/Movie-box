import { useCallback, useState } from 'react';
import { RepositoryError } from '../services/repositoryService';

export interface DisplayError {
  message: string;
  details: string[];
}

export function toDisplayError(e: unknown): DisplayError {
  if (e instanceof RepositoryError) return { message: e.message, details: e.details };
  if (e instanceof Error) return { message: e.message, details: [] };
  return { message: 'Something went wrong.', details: [] };
}

/** Runs async UI actions, tracking which one is busy and surfacing errors/notices. */
export function useAsyncAction() {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<DisplayError | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const run = useCallback(async (key: string, fn: () => Promise<string | void>) => {
    setBusy(key);
    setError(null);
    setNotice(null);
    try {
      const message = await fn();
      if (typeof message === 'string') setNotice(message);
    } catch (e) {
      setError(toDisplayError(e));
    } finally {
      setBusy(null);
    }
  }, []);

  return { run, busy, error, notice, clearError: () => setError(null), clearNotice: () => setNotice(null) };
}
