import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { addWatchlist, fetchWatchlist, removeWatchlist } from '../services/cloud';
import { useAuth } from './useAuth';

const KEY = 'moviebox-plus:watchlist:v1';

function load(): string[] {
  try {
    const v: unknown = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, 2000) : [];
  } catch {
    return [];
  }
}

interface WatchlistApi {
  ids: string[];
  has(id: string): boolean;
  toggle(id: string): void;
  syncError: string | null;
}

const Ctx = createContext<WatchlistApi | null>(null);

export function useWatchlist(): WatchlistApi {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useWatchlist must be used inside <WatchlistProvider>');
  return ctx;
}

export function WatchlistProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [ids, setIds] = useState<string[]>(load);
  const [syncError, setSyncError] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(ids));
    } catch {
      /* ignore */
    }
  }, [ids]);

  // On sign-in: merge cloud and local lists, then upload anything the cloud is missing.
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        const remote = await fetchWatchlist();
        if (cancelled) return;
        const merged = Array.from(new Set([...ids, ...remote]));
        setIds(merged);
        await addWatchlist(
          user.id,
          merged.filter((id) => !remote.includes(id)),
        );
        setSyncError(null);
      } catch (e) {
        if (!cancelled) setSyncError(e instanceof Error ? e.message : 'Cloud sync failed.');
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const toggle = useCallback(
    (id: string) => {
      const adding = !ids.includes(id);
      setIds((cur) => (adding ? [...cur, id] : cur.filter((x) => x !== id)));
      if (user) {
        (adding ? addWatchlist(user.id, [id]) : removeWatchlist(user.id, id)).catch((e) =>
          setSyncError(e instanceof Error ? e.message : 'Cloud sync failed.'),
        );
      }
    },
    [ids, user],
  );

  const value = useMemo(
    () => ({ ids, has: (id: string) => ids.includes(id), toggle, syncError }),
    [ids, toggle, syncError],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
