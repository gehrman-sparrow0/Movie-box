import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { builtinProvider } from '../providers/builtin';
import { createProvider, type ContentProvider } from '../providers';
import type { CatalogItem } from '../types/content';
import { useAddons } from './useAddons';

export interface CatalogError {
  addonId: string;
  name: string;
  message: string;
}

interface CatalogApi {
  items: CatalogItem[];
  loading: boolean;
  errors: CatalogError[];
  reload(): void;
  getProvider(origin: string): ContentProvider | undefined;
}

const Ctx = createContext<CatalogApi | null>(null);

export function useCatalog(): CatalogApi {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useCatalog must be used inside <CatalogProvider>');
  return ctx;
}

export function CatalogProvider({ children }: { children: ReactNode }) {
  const { installed } = useAddons();
  const [items, setItems] = useState<CatalogItem[]>([]);
  const [errors, setErrors] = useState<CatalogError[]>([]);
  const [loading, setLoading] = useState(true);
  const [nonce, setNonce] = useState(0);
  const providers = useRef(new Map<string, ContentProvider>());

  const key = installed
    .filter((a) => a.enabled)
    .map((a) => `${a.manifest.id}@${a.manifest.version}`)
    .join('|');

  useEffect(() => {
    const controller = new AbortController();
    const active = [builtinProvider, ...installed.filter((a) => a.enabled).map((a) => createProvider(a.manifest))];
    providers.current = new Map(active.map((p) => [p.id, p]));
    setLoading(true);

    Promise.allSettled(active.map((p) => p.getCatalog(controller.signal))).then((results) => {
      if (controller.signal.aborted) return;
      const nextItems: CatalogItem[] = [];
      const nextErrors: CatalogError[] = [];
      results.forEach((r, i) => {
        if (r.status === 'fulfilled') nextItems.push(...r.value);
        else {
          nextErrors.push({
            addonId: active[i].id,
            name: active[i].name,
            message: r.reason instanceof Error ? r.reason.message : 'Could not load this catalog.',
          });
        }
      });
      setItems(nextItems);
      setErrors(nextErrors);
      setLoading(false);
    });

    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, nonce]);

  const getProvider = useCallback((origin: string) => providers.current.get(origin), []);
  const reload = useCallback(() => setNonce((n) => n + 1), []);

  const value = useMemo(
    () => ({ items, loading, errors, reload, getProvider }),
    [items, loading, errors, reload, getProvider],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
