import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { config } from '../config';
import { compareSemver } from '../lib/semver';
import { parseSafeUrl, SecurityError } from '../lib/security';
import { loadState, saveState, type PersistedState } from '../services/addonStorage';
import {
  fetchAddonManifest,
  fetchRepository,
  parseAddonManifest,
  RepositoryError,
} from '../services/repositoryService';
import type { AddonManifest, AddonSource, InstalledAddon, RepositoryEntry, ResolvedRepository } from '../types/addon';
import { toDisplayError } from './useAsyncAction';

export interface RepoStatus {
  url: string;
  status: 'loading' | 'ready' | 'error';
  data?: ResolvedRepository;
  error?: string;
  details?: string[];
}

interface AddonsApi {
  repositories: PersistedState['repositories'];
  repoStatus: Record<string, RepoStatus>;
  installed: InstalledAddon[];
  addRepository(url: string): Promise<void>;
  removeRepository(url: string): void;
  refreshRepository(url: string): Promise<void>;
  installFromRepository(repositoryUrl: string, entry: RepositoryEntry): Promise<void>;
  importLocalManifest(file: File): Promise<void>;
  setEnabled(id: string, enabled: boolean): void;
  uninstall(id: string): void;
  updateAddon(id: string): Promise<'updated' | 'current'>;
  getUpdate(id: string): RepositoryEntry | undefined;
}

const Ctx = createContext<AddonsApi | null>(null);

export function useAddons(): AddonsApi {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAddons must be used inside <AddonsProvider>');
  return ctx;
}

export function AddonsProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(loadState);
  const [repoStatus, setRepoStatus] = useState<Record<string, RepoStatus>>({});

  useEffect(() => {
    saveState(state);
  }, [state]);

  const loadRepo = useCallback(async (url: string): Promise<ResolvedRepository> => {
    setRepoStatus((s) => ({ ...s, [url]: { url, status: 'loading', data: s[url]?.data } }));
    try {
      const data = await fetchRepository(url);
      setRepoStatus((s) => ({ ...s, [url]: { url, status: 'ready', data } }));
      return data;
    } catch (e) {
      const err = toDisplayError(e);
      setRepoStatus((s) => ({
        ...s,
        [url]: { url, status: 'error', error: err.message, details: err.details, data: s[url]?.data },
      }));
      throw e;
    }
  }, []);

  // Refresh known repositories once on startup (needed to detect updates).
  useEffect(() => {
    state.repositories.forEach((r) => {
      loadRepo(r.url).catch(() => undefined);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const install = useCallback((manifest: AddonManifest, source: AddonSource) => {
    setState((s) => {
      const existing = s.installed.find((a) => a.manifest.id === manifest.id);
      const record: InstalledAddon = {
        manifest,
        enabled: existing?.enabled ?? true,
        installedAt: existing?.installedAt ?? new Date().toISOString(),
        source,
      };
      return {
        ...s,
        installed: existing
          ? s.installed.map((a) => (a.manifest.id === manifest.id ? record : a))
          : [...s.installed, record],
      };
    });
  }, []);

  const addRepository = useCallback(
    async (rawUrl: string) => {
      let url: string;
      try {
        url = parseSafeUrl(rawUrl.trim()).href;
      } catch (e) {
        throw new RepositoryError(
          `This repository URL cannot be used. ${e instanceof SecurityError ? e.message : ''}`.trim(),
          config.allowInsecureDev ? [] : ['Only public HTTPS URLs are accepted.'],
        );
      }
      if (state.repositories.some((r) => r.url === url)) {
        throw new RepositoryError('This repository has already been added.');
      }
      const data = await loadRepo(url);
      setState((s) => ({
        ...s,
        repositories: [...s.repositories, { url, name: data.manifest.name, addedAt: new Date().toISOString() }],
      }));
    },
    [state.repositories, loadRepo],
  );

  const removeRepository = useCallback((url: string) => {
    setState((s) => ({ ...s, repositories: s.repositories.filter((r) => r.url !== url) }));
    setRepoStatus((s) => {
      const next = { ...s };
      delete next[url];
      return next;
    });
  }, []);

  const installFromRepository = useCallback(
    async (repositoryUrl: string, entry: RepositoryEntry) => {
      const manifest = await fetchAddonManifest(entry.manifestUrl);
      if (manifest.id !== entry.id) {
        throw new RepositoryError('The add-on manifest does not match its repository listing.', [
          `Listed id: ${entry.id}`,
          `Manifest id: ${manifest.id}`,
        ]);
      }
      install(manifest, { kind: 'repository', repositoryUrl, manifestUrl: entry.manifestUrl });
    },
    [install],
  );

  const importLocalManifest = useCallback(
    async (file: File) => {
      if (!file.name.toLowerCase().endsWith('.json')) {
        throw new RepositoryError('Choose a .json add-on manifest file.');
      }
      if (file.size > config.maxManifestBytes) {
        throw new RepositoryError('This file is too large to be an add-on manifest.');
      }
      let data: unknown;
      try {
        data = JSON.parse(await file.text());
      } catch {
        throw new RepositoryError('This file is not valid JSON.');
      }
      install(parseAddonManifest(data), { kind: 'local' });
    },
    [install],
  );

  const setEnabled = useCallback((id: string, enabled: boolean) => {
    setState((s) => ({
      ...s,
      installed: s.installed.map((a) => (a.manifest.id === id ? { ...a, enabled } : a)),
    }));
  }, []);

  const uninstall = useCallback((id: string) => {
    setState((s) => ({ ...s, installed: s.installed.filter((a) => a.manifest.id !== id) }));
  }, []);

  const updateAddon = useCallback(
    async (id: string): Promise<'updated' | 'current'> => {
      const record = state.installed.find((a) => a.manifest.id === id);
      if (!record || record.source.kind !== 'repository' || !record.source.manifestUrl) {
        throw new RepositoryError('This add-on was imported from a file and cannot be updated automatically.');
      }
      const manifest = await fetchAddonManifest(record.source.manifestUrl);
      if (manifest.id !== id) {
        throw new RepositoryError('The updated manifest has a different id and was rejected.');
      }
      if (compareSemver(manifest.version, record.manifest.version) <= 0) return 'current';
      install(manifest, record.source);
      return 'updated';
    },
    [state.installed, install],
  );

  const getUpdate = useCallback(
    (id: string): RepositoryEntry | undefined => {
      const record = state.installed.find((a) => a.manifest.id === id);
      const repoUrl = record?.source.repositoryUrl;
      if (!record || !repoUrl) return undefined;
      const entry = repoStatus[repoUrl]?.data?.addons.find((a) => a.id === id);
      return entry && compareSemver(entry.version, record.manifest.version) > 0 ? entry : undefined;
    },
    [state.installed, repoStatus],
  );

  const value = useMemo<AddonsApi>(
    () => ({
      repositories: state.repositories,
      repoStatus,
      installed: state.installed,
      addRepository,
      removeRepository,
      refreshRepository: async (url) => {
        await loadRepo(url);
      },
      installFromRepository,
      importLocalManifest,
      setEnabled,
      uninstall,
      updateAddon,
      getUpdate,
    }),
    [
      state,
      repoStatus,
      addRepository,
      removeRepository,
      loadRepo,
      installFromRepository,
      importLocalManifest,
      setEnabled,
      uninstall,
      updateAddon,
      getUpdate,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
