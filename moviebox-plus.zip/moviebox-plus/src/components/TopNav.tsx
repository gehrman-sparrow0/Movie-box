import { Link, NavLink } from 'react-router-dom';
import { Play } from 'lucide-react';
import { NAV_ITEMS } from './navItems';

export default function TopNav() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-bg/[0.85] backdrop-blur-lg">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 md:px-8">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-accent text-bg">
            <Play className="h-3.5 w-3.5 fill-current" aria-hidden />
          </span>
          MovieBox Plus
        </Link>
        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map(({ to, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `rounded-lg px-3 py-1.5 text-sm transition ${
                  isActive ? 'bg-white/10 text-accent' : 'text-slate-300 hover:bg-white/5'
                }`
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
