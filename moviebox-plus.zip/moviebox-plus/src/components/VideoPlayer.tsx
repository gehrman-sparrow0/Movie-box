import { useEffect, useMemo, useRef, useState } from 'react';
import type HlsType from 'hls.js';
import { AlertTriangle, Loader2, SkipForward, VideoOff } from 'lucide-react';
import { parseSafeUrl } from '../lib/security';
import type { StreamSource } from '../types/content';
import { isSafeImageSrc } from './Poster';

interface Props {
  sources: StreamSource[];
  title: string;
  poster?: string;
}

const MEDIA_ERRORS: Record<number, string> = {
  1: 'Playback was interrupted.',
  2: 'A network error interrupted the download.',
  3: 'This media could not be decoded.',
  4: 'This format or source is not supported by your browser.',
};

/**
 * Responsive HTML5 player. Plain MP4/WebM use the native element; HLS uses native
 * support (Safari/iOS) or hls.js (loaded on demand). Every URL is re-validated
 * against the URL policy before it is handed to the media element.
 */
export default function VideoPlayer({ sources, title, poster }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [index, setIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const checked = useMemo(
    () =>
      sources.map((source) => {
        try {
          return { source, url: parseSafeUrl(source.url).href, problem: null as string | null };
        } catch (e) {
          return { source, url: '', problem: e instanceof Error ? e.message : 'Invalid URL.' };
        }
      }),
    [sources],
  );
  const current = checked[index];

  useEffect(() => setIndex(0), [sources]);

  useEffect(() => {
    const video = videoRef.current;
    setError(null);
    if (!video || !current) return;
    if (current.problem) {
      setError(`This source was blocked: ${current.problem}`);
      setLoading(false);
      return;
    }
    setLoading(true);
    let hls: HlsType | null = null;
    let cancelled = false;

    const start = async () => {
      if (current.source.type !== 'hls' || video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = current.url;
        return;
      }
      const { default: Hls } = await import('hls.js');
      if (cancelled) return;
      if (!Hls.isSupported()) {
        setError('HLS streams are not supported in this browser.');
        setLoading(false);
        return;
      }
      hls = new Hls({ enableWorker: true });
      let recovered = false;
      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (!data.fatal) return;
        if (data.type === Hls.ErrorTypes.MEDIA_ERROR && !recovered) {
          recovered = true;
          hls?.recoverMediaError();
          return;
        }
        setError(
          data.type === Hls.ErrorTypes.NETWORK_ERROR
            ? 'The stream could not be loaded. It may be offline or blocked by the server (CORS).'
            : 'The stream could not be played.',
        );
        setLoading(false);
        hls?.destroy();
      });
      hls.loadSource(current.url);
      hls.attachMedia(video);
    };

    start().catch(() => {
      if (!cancelled) {
        setError('The player could not be started.');
        setLoading(false);
      }
    });

    return () => {
      cancelled = true;
      hls?.destroy();
    };
  }, [current]);

  if (checked.length === 0) {
    return (
      <div className="grid aspect-video place-items-center rounded-2xl border border-dashed border-white/10 bg-surface p-6 text-center">
        <div>
          <VideoOff className="mx-auto mb-3 h-8 w-8 text-slate-500" aria-hidden />
          <p className="font-medium">No playable source</p>
          <p className="mt-1 text-sm text-slate-400">This title does not list any streaming sources yet.</p>
        </div>
      </div>
    );
  }

  const hasNext = index < checked.length - 1;

  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-black">
      <div className="relative aspect-video">
        <video
          ref={videoRef}
          className="h-full w-full bg-black"
          controls
          playsInline
          preload="metadata"
          poster={isSafeImageSrc(poster) ? poster : undefined}
          aria-label={title}
          onCanPlay={() => setLoading(false)}
          onPlaying={() => setLoading(false)}
          onWaiting={() => setLoading(true)}
          onError={() => {
            const code = videoRef.current?.error?.code ?? 4;
            setError(MEDIA_ERRORS[code] ?? MEDIA_ERRORS[4]);
            setLoading(false);
          }}
        />
        {loading && !error && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center bg-black/30">
            <Loader2 className="h-8 w-8 animate-spin text-accent" aria-label="Loading video" />
          </div>
        )}
        {error && (
          <div role="alert" className="absolute inset-0 grid place-items-center bg-black/[0.85] p-6 text-center">
            <div className="max-w-sm">
              <AlertTriangle className="mx-auto mb-3 h-8 w-8 text-accent" aria-hidden />
              <p className="font-medium">This source can’t be played</p>
              <p className="mt-1 text-sm text-slate-300">{error}</p>
              {hasNext && (
                <button className="btn btn-primary mt-4" onClick={() => setIndex(index + 1)}>
                  <SkipForward className="h-4 w-4" aria-hidden /> Try the next source
                </button>
              )}
            </div>
          </div>
        )}
      </div>
      {checked.length > 1 && (
        <div className="flex flex-wrap items-center gap-2 border-t border-white/10 bg-surface px-3 py-2.5">
          <span className="text-xs text-slate-400">Source</span>
          {checked.map((c, i) => (
            <button
              key={i}
              onClick={() => setIndex(i)}
              aria-pressed={i === index}
              className={`chip ${i === index ? 'chip-active' : ''}`}
            >
              {c.source.label ?? `${c.source.type.toUpperCase()} ${i + 1}`}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
