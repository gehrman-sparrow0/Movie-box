import { Outlet, useLocation } from 'react-router-dom';
import BottomNav from './BottomNav';
import TopNav from './TopNav';

export default function AppShell() {
  const { pathname } = useLocation();
  return (
    <div className="min-h-screen">
      <TopNav />
      <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-5 md:px-8 md:pb-12">
        {/* keyed on the route so each page eases in once when you navigate */}
        <div key={pathname} className="animate-fade-in">
          <Outlet />
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
