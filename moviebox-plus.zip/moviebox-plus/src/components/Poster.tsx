import { useState } from 'react';
import { config } from '../config';

function hue(s: string): number {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
}

/** Only render images from data: URIs, HTTPS, or (dev flag) HTTP. */
export function isSafeImageSrc(src?: string): src is string {
  if (!src) return false;
  return (
    src.startsWith('data:image/') ||
    src.startsWith('https://') ||
    (config.allowInsecureDev && src.startsWith('http://'))
  );
}

export default function Poster({ src, title, className = '' }: { src?: string; title: string; className?: string }) {
  const [failed, setFailed] = useState(false);

  if (!isSafeImageSrc(src) || failed) {
    const h = hue(title);
    return (
      <div
        className={`flex items-end p-3 ${className}`}
        style={{ background: `linear-gradient(135deg, hsl(${h} 55% 38%), hsl(${(h + 70) % 360} 60% 12%))` }}
        role="img"
        aria-label={`${title} poster`}
      >
        <span className="font-display text-sm font-bold leading-tight">{title}</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={`${title} poster`}
      loading="lazy"
      decoding="async"
      onError={() => setFailed(true)}
      className={`object-cover ${className}`}
    />
  );
}
