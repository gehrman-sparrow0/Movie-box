import { AlertTriangle, X } from 'lucide-react';

interface Props {
  title: string;
  details?: string[];
  onDismiss?: () => void;
}

export default function ErrorBanner({ title, details = [], onDismiss }: Props) {
  return (
    <div role="alert" className="flex gap-3 rounded-xl border border-red-400/20 bg-red-500/10 p-3.5 text-sm">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-300" aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="font-medium text-red-100">{title}</p>
        {details.length > 0 && (
          <ul className="mt-1 list-disc space-y-0.5 pl-4 text-red-200/80">
            {details.map((d, i) => (
              <li key={i} className="break-words">
                {d}
              </li>
            ))}
          </ul>
        )}
      </div>
      {onDismiss && (
        <button onClick={onDismiss} aria-label="Dismiss error" className="text-red-200/70 hover:text-red-100">
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
