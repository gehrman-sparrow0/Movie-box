export const Skeleton = ({ className = '' }: { className?: string }) => (
  <div className={`skeleton ${className}`} aria-hidden />
);

export const PosterSkeleton = ({ className = '' }: { className?: string }) => (
  <div className={className} aria-hidden>
    <Skeleton className="aspect-[2/3] w-full" />
    <Skeleton className="mt-2 h-3.5 w-4/5" />
    <Skeleton className="mt-1.5 h-3 w-1/2" />
  </div>
);

export const RowSkeleton = () => (
  <div aria-busy="true" aria-label="Loading">
    <Skeleton className="mb-3 h-6 w-40" />
    <div className="flex gap-3 overflow-hidden">
      {Array.from({ length: 7 }, (_, i) => (
        <PosterSkeleton key={i} className="w-32 shrink-0 sm:w-36 md:w-40" />
      ))}
    </div>
  </div>
);

export const GridSkeleton = ({ count = 12 }: { count?: number }) => (
  <div
    className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6"
    aria-busy="true"
    aria-label="Loading"
  >
    {Array.from({ length: count }, (_, i) => (
      <PosterSkeleton key={i} />
    ))}
  </div>
);
