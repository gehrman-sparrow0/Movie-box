import { Link } from 'react-router-dom';
import { Info, Play, Star } from 'lucide-react';
import type { CatalogItem } from '../types/content';
import Poster, { isSafeImageSrc } from './Poster';

export default function Hero({ item }: { item: CatalogItem }) {
  const id = encodeURIComponent(item.id);
  const backdrop = item.backdrop ?? item.poster;
  return (
    <section className="relative overflow-hidden rounded-3xl border border-white/5 bg-surface">
      {isSafeImageSrc(backdrop) && (
        <img
          src={backdrop}
          alt=""
          className="absolute inset-0 h-full w-full scale-125 object-cover opacity-[0.35] blur-2xl"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" />
      <div className="relative flex items-end gap-5 p-5 pt-24 md:p-10 md:pt-32">
        <Poster
          src={item.poster}
          title={item.title}
          className="hidden h-52 w-36 shrink-0 rounded-xl shadow-2xl ring-1 ring-white/10 sm:block"
        />
        <div className="min-w-0">
          <p className="mb-2 inline-flex items-center gap-1.5 text-sm text-accent">
            <Star className="h-4 w-4 fill-current" aria-hidden />
            {item.rating.toFixed(1)} rated, top pick in your library
          </p>
          <h1 className="text-3xl font-semibold leading-tight md:text-5xl">{item.title}</h1>
          <p className="mt-1.5 flex gap-3 text-sm text-slate-300">
            <span>{item.year}</span>
            <span>{item.genres.slice(0, 3).join(', ')}</span>
          </p>
          <p className="mt-3 line-clamp-2 max-w-xl text-sm text-slate-300">{item.synopsis}</p>
          <div className="mt-4 flex gap-2.5">
            <Link to={`/watch/${id}`} className="btn btn-primary">
              <Play className="h-4 w-4 fill-current" aria-hidden /> Play
            </Link>
            <Link to={`/title/${id}`} className="btn btn-ghost">
              <Info className="h-4 w-4" aria-hidden /> Details
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
