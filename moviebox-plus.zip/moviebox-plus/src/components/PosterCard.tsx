import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import type { CatalogItem } from '../types/content';
import Poster from './Poster';

export default function PosterCard({ item, className = '' }: { item: CatalogItem; className?: string }) {
  return (
    <Link to={`/title/${encodeURIComponent(item.id)}`} className={`group block ${className}`}>
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-surface2 ring-1 ring-white/5 transition group-hover:ring-accent/60">
        <Poster
          src={item.poster}
          title={item.title}
          className="h-full w-full transition duration-300 group-hover:scale-105"
        />
        <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-md bg-black/[0.65] px-1.5 py-0.5 text-[11px] font-semibold backdrop-blur">
          <Star className="h-3 w-3 fill-accent text-accent" aria-hidden />
          {item.rating.toFixed(1)}
        </span>
        {item.type === 'anime' && (
          <span className="absolute bottom-2 right-2 rounded-md bg-sea/90 px-1.5 py-0.5 text-[11px] font-semibold text-bg">
            Anime
          </span>
        )}
      </div>
      <h3 className="mt-2 truncate font-sans text-sm font-medium">{item.title}</h3>
      <p className="flex gap-2 truncate text-xs text-slate-400">
        <span>{item.year}</span>
        <span className="truncate">{item.genres.slice(0, 2).join(', ')}</span>
      </p>
    </Link>
  );
}
