import { Bookmark, Clapperboard, Film, Home, Search, Settings, type LucideIcon } from 'lucide-react';

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Home', icon: Home },
  { to: '/search', label: 'Search', icon: Search },
  { to: '/movies', label: 'Movies', icon: Film },
  { to: '/anime', label: 'Anime', icon: Clapperboard },
  { to: '/watchlist', label: 'Watchlist', icon: Bookmark },
  { to: '/settings', label: 'Settings', icon: Settings },
];
