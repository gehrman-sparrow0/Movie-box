import type { CatalogItem } from '../types/content';
import PosterCard from './PosterCard';

export default function ContentRow({ title, items }: { title: string; items: CatalogItem[] }) {
  if (items.length === 0) return null;
  return (
    <section aria-label={title}>
      <h2 className="mb-3 text-xl font-semibold">{title}</h2>
      <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
        {items.map((item) => (
          <PosterCard key={item.id} item={item} className="w-32 shrink-0 snap-start sm:w-36 md:w-40" />
        ))}
      </div>
    </section>
  );
}
