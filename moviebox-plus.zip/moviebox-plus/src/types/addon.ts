import type { z } from 'zod';
import type { addonManifestSchema, repositoryEntrySchema, repositoryManifestSchema } from '../schemas/addon';

export type AddonManifest = z.infer<typeof addonManifestSchema>;
export type RepositoryEntry = z.infer<typeof repositoryEntrySchema>;
export type RepositoryManifest = z.infer<typeof repositoryManifestSchema>;

/** A repository manifest whose entry `manifestUrl`s have been resolved to absolute, validated URLs. */
export interface ResolvedRepository {
  url: string;
  manifest: RepositoryManifest;
  addons: RepositoryEntry[];
}

export interface AddonSource {
  kind: 'repository' | 'local';
  repositoryUrl?: string;
  manifestUrl?: string;
}

export interface InstalledAddon {
  manifest: AddonManifest;
  enabled: boolean;
  installedAt: string;
  source: AddonSource;
}

export interface RepositoryRecord {
  url: string;
  name: string;
  addedAt: string;
}
