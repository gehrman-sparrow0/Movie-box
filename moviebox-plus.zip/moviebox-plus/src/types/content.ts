import type { z } from 'zod';
import type { contentItemSchema, episodeSchema, streamSourceSchema } from '../schemas/addon';

export type StreamSource = z.infer<typeof streamSourceSchema>;
export type Episode = z.infer<typeof episodeSchema>;
export type ContentItem = z.infer<typeof contentItemSchema>;
export type ContentType = ContentItem['type'];

/** A content item plus the provider that supplied it. `id` is namespaced as `<origin>~<id>`. */
export type CatalogItem = ContentItem & { origin: string; originName: string };
