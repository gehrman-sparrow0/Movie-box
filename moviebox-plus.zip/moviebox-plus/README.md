# MovieBox Plus

A mobile-first movie and anime browsing app with a modular, **data-only** add-on system and an HTML5/HLS
player. Built with React, TypeScript, Vite and Tailwind CSS, with optional Supabase accounts for a cloud
watchlist. The UI and code are original. The add-on idea is inspired by extension-based apps, but nothing here
is copied from them.

> **Use it lawfully.** MovieBox Plus only plays sources you are authorized to access. It does not scrape
> services, bypass DRM or ship any copyrighted media. The bundled samples use openly licensed Blender
> Foundation films and public test streams.

## Features

- Home, Search, Movies, Anime, Watchlist and Settings, with bottom navigation on mobile and a top bar on desktop
- Posters, ratings, genres, release years, details pages, episode lists, skeleton loaders and empty states
- Add-on system: add a repository URL, validate manifests, install, enable, disable, update, uninstall,
  import a manifest from a local file, persisted in `localStorage`
- Strict JSON schemas (Zod), documented in [`docs/manifest-schema.md`](docs/manifest-schema.md)
- Player for MP4/WebM and HLS (native on Safari, hls.js elsewhere) with readable error messages
- Optional Supabase sign-in (email link) and cloud watchlist

## Requirements

- Node.js 18.18 or newer (20 LTS recommended) and npm
- Git, and a GitHub account if you want to publish

## Run it locally

```bash
# 1. Install dependencies
npm install

# 2. Create your local environment file
cp .env.example .env          # Windows: copy .env.example .env

# 3. Start the dev server (http://localhost:5173)
npm run dev
```

Other scripts:

| Command | What it does |
| --- | --- |
| `npm test` | Runs the Vitest suite (schema validation, repository parsing, URL security) |
| `npm run typecheck` | TypeScript check with no output |
| `npm run build` | Type-checks, then builds to `dist/` |
| `npm run preview` | Serves the production build locally |

### Try the add-on system

1. Open **Settings, then Add-ons and repositories**.
2. Tap **Use the sample repository** and **Add**. In dev this serves from `http://localhost:5173/...`, which is
   allowed because `.env` has `VITE_ALLOW_INSECURE_DEV=true`.
3. Install **Open Cinema Demo** (bundled catalog) and **Remote Catalog Demo** (loads a JSON catalog remotely).
   New titles appear in Home, Movies and Anime.
4. Toggle an add-on off to remove its titles, or uninstall it.
5. To test local import, choose `public/addons/sample-addon.json` under **Import from file**.

## Project structure

```
src/
  main.tsx, App.tsx          Entry point, providers, routes (HashRouter)
  config.ts                  Env-driven settings and limits
  components/                AppShell, BottomNav, TopNav, PosterCard, ContentRow, Hero,
                             VideoPlayer, Skeleton, EmptyState, ErrorBanner, FilterChips
  pages/                     Home, Search, Browse (Movies/Anime), Watchlist, Settings,
                             Addons, Details, Watch
  hooks/                     useAddons, useCatalog, useWatchlist, useAuth, useAsyncAction
  providers/                 ContentProvider interface + builtin / static / remote providers
  schemas/addon.ts           Strict Zod schemas for repositories, add-ons and catalogs
  services/                  repositoryService, addonStorage, supabase, cloud
  lib/                       security (URL policy), http (hardened fetch), semver
  data/sampleContent.ts      Built-in sample titles
  types/                     Shared TypeScript types
public/
  repo/sample-repository.json
  addons/sample-addon.json, sample-remote-addon.json, sample-catalog.json
supabase/schema.sql          Table and row-level security for the cloud watchlist
.github/workflows/deploy.yml GitHub Pages deployment
```

## Security model

| Concern | Mitigation |
| --- | --- |
| Arbitrary code from add-ons | Add-ons are JSON only. There is no `eval`, dynamic import or script loading from manifests |
| Malformed input | Every repository, manifest, catalog and persisted record is parsed with a strict Zod schema with size limits. Unknown keys are rejected |
| Insecure or malicious URLs | Only public `https:` URLs. Credentials in URLs, non-default ports, `localhost`, single-label hosts, `.local`/`.internal` names, private, loopback, link-local and IPv4-mapped addresses are rejected. Numeric IP tricks are normalised by the URL parser first |
| Unsafe redirects | Requests use `redirect: 'error'`, so a server cannot bounce a request to an internal host |
| Cross-origin requests | Plain `GET` with `credentials: 'omit'`, `referrerPolicy: 'no-referrer'`, and a timeout and size cap. The browser's CORS rules still apply, and servers must opt in |
| Media URLs | Validated in the schema and again in the player. Only `mp4`, `webm` and `hls` types are accepted |
| XSS | React escapes all text. Image sources must be `https:` or `data:image/`. A production CSP is injected at build time (`vite.config.ts`) with `script-src 'self'` and `object-src 'none'` |
| Secrets | Only `VITE_*` values reach the browser, and the app only needs the public Supabase anon key. Data is protected by row-level security (`supabase/schema.sql`). Never put a service-role key in this project |
| Authorized content | Add-ons must carry a `contentRights` statement, shown at install. The player does not bypass DRM or authentication |

**Limits to know about.** A static browser app cannot resolve DNS, so a hostname that *later* resolves to a
private address (DNS rebinding) cannot be detected client-side. The browser also cannot reach private networks
from a public HTTPS page without the target opting in. If you ever add a server-side proxy to fetch repositories,
repeat these checks there, resolve DNS yourself, and pin the resolved IP for the request.

`VITE_ALLOW_INSECURE_DEV=true` relaxes the URL policy for local testing. It is only honoured when
`import.meta.env.DEV` is true, so it has no effect in `npm run build` output.

## Optional: Supabase accounts and cloud watchlist

1. Create a project at [supabase.com](https://supabase.com).
2. Open **SQL editor**, paste `supabase/schema.sql` and run it.
3. Open **Authentication, URL configuration**. Set **Site URL** to your deployed URL (for example
   `https://<user>.github.io/<repo>/`) and add `http://localhost:5173/` as a redirect URL for development.
4. Copy the **Project URL** and **anon public key** from **Project settings, API** into `.env`:

   ```
   VITE_SUPABASE_URL=https://xxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...
   ```

5. Restart `npm run dev`. **Settings, Account** now offers an email sign-in link. After sign-in, your local
   and cloud watchlists are merged.

Leave both variables empty and the app works entirely offline with local storage.

## Publish to GitHub Pages

The included workflow builds and deploys on every push to `main`.

1. Create an empty repository on GitHub, for example `moviebox-plus`.
2. In the project folder:

   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-user>/moviebox-plus.git
   git push -u origin main
   ```

3. On GitHub open **Settings, Pages** and set **Source** to **GitHub Actions**.
4. (Optional) Under **Settings, Secrets and variables, Actions, Variables**, add `VITE_SUPABASE_URL` and
   `VITE_SUPABASE_ANON_KEY` if you use Supabase. The anon key is public by design.
5. Push to `main` (or run the workflow from the **Actions** tab). The site appears at
   `https://<your-user>.github.io/moviebox-plus/`.

Notes:

- The workflow sets `VITE_BASE_PATH=/<repo-name>/` automatically. For a custom domain or a `<user>.github.io`
  repository, remove that line so the base is `/`.
- Routing uses the URL hash (`/#/movies`), so refreshing any page works on static hosting.
- After your first `npm install`, commit the generated `package-lock.json` and change `npm install` to
  `npm ci` in the workflow for reproducible builds.
- Your sample repository will be public at `https://<user>.github.io/<repo>/repo/sample-repository.json`.
  Other repositories must allow cross-origin `GET` requests. GitHub Pages and `raw.githubusercontent.com` do.

### Other hosts

Any static host works. The build output is `dist/`.

- **Netlify / Cloudflare Pages / Vercel:** build command `npm run build`, output directory `dist`. No base
  path variable is needed when served from the domain root.
- **Manual:** run `npm run build` and upload `dist/` to any web server over HTTPS.

## Writing your own repository

Host a `repository.json` and add-on manifests anywhere that serves HTTPS with CORS enabled, following
[`docs/manifest-schema.md`](docs/manifest-schema.md). Start by copying the files in `public/repo` and
`public/addons`.

## Testing

`npm test` covers:

- Manifest schema validation: strict keys, ids, versions, unsafe URLs, unsupported stream types
- Repository parsing: relative URL resolution, error reporting, duplicate ids
- Fetching: HTTPS enforcement, private hosts blocked before any request, HTTP errors, network errors, wrong
  content type, invalid JSON, oversized responses
- URL policy: private ranges, IPv6 forms, credentials, ports, dev exceptions

## Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| "Network error ... CORS" when adding a repository | The server does not send `Access-Control-Allow-Origin`, or it redirects. Redirects are refused by design |
| "Only HTTPS URLs are allowed" for the sample repo in dev | Set `VITE_ALLOW_INSECURE_DEV=true` in `.env` and restart the dev server |
| Video shows "can't be played" | The file is unreachable, blocked by CORS (HLS needs CORS), or the codec is unsupported by your browser |
| Blank page on GitHub Pages | `VITE_BASE_PATH` does not match the repository name. Check the workflow's build step |
