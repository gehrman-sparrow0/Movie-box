-- Run once in the Supabase SQL editor. Enables a per-user cloud watchlist.
create table if not exists public.watchlist (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  item_id text not null check (char_length(item_id) <= 200),
  created_at timestamptz not null default now(),
  primary key (user_id, item_id)
);

alter table public.watchlist enable row level security;

create policy "read own watchlist" on public.watchlist
  for select using (auth.uid() = user_id);
create policy "insert own watchlist" on public.watchlist
  for insert with check (auth.uid() = user_id);
create policy "update own watchlist" on public.watchlist
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "delete own watchlist" on public.watchlist
  for delete using (auth.uid() = user_id);
