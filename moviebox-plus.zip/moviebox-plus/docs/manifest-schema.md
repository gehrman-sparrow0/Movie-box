# Manifest schema (version 1)

Add-ons are **data, not code**. MovieBox Plus never executes JavaScript from a manifest, repository or
catalog. Every JSON document is validated with a strict [Zod](https://zod.dev) schema
(`src/schemas/addon.ts`): unknown properties are rejected, strings and arrays have size limits, and every URL
must pass the URL policy (public HTTPS only, no credentials, no private hosts, default port only).

URL fields marked *relative OK* may also be a relative path such as `../addons/a.json`. It is resolved against
the URL of the document that contains it, then re-validated.

## Repository manifest

```json
{
  "schemaVersion": 1,
  "id": "my-repository",
  "name": "My repository",
  "description": "Optional text",
  "maintainer": "Optional name",
  "addons": [
    {
      "id": "com.example.my-addon",
      "name": "My add-on",
      "version": "1.2.0",
      "description": "What it provides",
      "manifestUrl": "https://example.com/addons/my-addon.json",
      "types": ["movie", "anime"],
      "icon": "https://example.com/icon.png"
    }
  ]
}
```

| Field | Type | Rules |
| --- | --- | --- |
| `schemaVersion` | `1` | Required |
| `id` | string | `a-z`, `0-9`, `-`, 3 to 64 chars |
| `name` | string | 1 to 60 chars |
| `description`, `maintainer` | string | Optional |
| `addons[]` | array | Max 200 entries, unique `id`s |
| `addons[].id` | string | Reverse-DNS, e.g. `com.example.my-addon` |
| `addons[].version` | string | Semver `MAJOR.MINOR.PATCH[-pre]` |
| `addons[].manifestUrl` | string | HTTPS URL, *relative OK* |
| `addons[].types` | array | One or both of `movie`, `anime` |
| `addons[].icon` | string | Optional HTTPS URL |

The `id` and `version` in a repository entry must match the add-on manifest it points to. A mismatched `id` is
rejected at install time.

## Add-on manifest

```json
{
  "schemaVersion": 1,
  "id": "com.example.my-addon",
  "name": "My add-on",
  "version": "1.2.0",
  "description": "What it provides",
  "author": "Your name",
  "homepage": "https://example.com",
  "icon": "https://example.com/icon.png",
  "types": ["movie"],
  "contentRights": "Why the user is authorized to access this content (licence, ownership, subscription...).",
  "provider": { "kind": "static", "items": [] }
}
```

| Field | Type | Rules |
| --- | --- | --- |
| `schemaVersion` | `1` | Required |
| `id` | string | Reverse-DNS, 3 to 100 chars |
| `name` | string | 1 to 60 chars |
| `version` | string | Semver |
| `description` | string | Up to 300 chars |
| `author` | string | 1 to 80 chars |
| `homepage`, `icon` | string | Optional HTTPS URL |
| `types` | array | `movie` and/or `anime` |
| `contentRights` | string | 10 to 500 chars. Shown to the user at install time |
| `provider` | object | `static` or `remote` (below) |

### Provider `static`

```json
{ "kind": "static", "items": [ /* content items, max 200 */ ] }
```

### Provider `remote`

```json
{ "kind": "remote", "catalogUrl": "https://example.com/catalog.json" }
```

`catalogUrl` is *relative OK* for add-ons installed from a repository (resolved against the add-on manifest
URL). Add-ons imported from a local file must use an absolute URL. The endpoint must return a **catalog**:

```json
{ "schemaVersion": 1, "items": [ /* content items, max 500 */ ] }
```

The endpoint must be reachable with a plain CORS `GET` (no cookies, no redirects).

## Content item

```json
{
  "id": "my-movie",
  "title": "My Movie",
  "type": "movie",
  "year": 2024,
  "rating": 7.8,
  "genres": ["Drama"],
  "synopsis": "Short description.",
  "durationMinutes": 112,
  "poster": "https://example.com/poster.jpg",
  "backdrop": "https://example.com/backdrop.jpg",
  "sources": [{ "url": "https://example.com/movie.mp4", "type": "mp4", "label": "1080p" }],
  "episodes": [{ "number": 1, "title": "Pilot", "sources": [{ "url": "https://example.com/e1.m3u8", "type": "hls" }] }]
}
```

| Field | Rules |
| --- | --- |
| `id` | `A-Za-z0-9_-`, 1 to 64 chars. Namespaced in the app as `<addonId>~<id>` so add-ons cannot collide |
| `type` | `movie` or `anime` |
| `year` | Integer 1888 to 2100 |
| `rating` | 0 to 10 |
| `genres` | Up to 8 strings (max 30 chars) |
| `poster`, `backdrop` | Optional HTTPS URLs |
| `sources[]` | Max 10. `type` is `mp4`, `webm` or `hls`. `url` must be a public HTTPS URL |
| `episodes[]` | Optional, max 500. Each has its own `sources` |

Only list media you are authorized to distribute or access. The player does not bypass DRM or authentication.

## Provider interface

Defined in `src/providers/types.ts`. Each enabled add-on becomes one provider:

```ts
interface ContentProvider {
  readonly id: string;
  readonly name: string;
  getCatalog(signal?: AbortSignal): Promise<CatalogItem[]>;                       // content metadata
  getSources(item: ContentItem, episodeNumber?: number): Promise<StreamSource[]>; // authorized stream URLs
}
```

`createProvider(manifest)` in `src/providers/index.ts` picks the implementation: `static.ts` serves the items
embedded in the manifest, `remote.ts` fetches and validates the catalog. To add a new provider *kind*, extend the
`providerSchema` union in `src/schemas/addon.ts` and add a factory. Keep it declarative: data in, data out.
