import { defineConfig, loadEnv } from 'vitest/config';
import react from '@vitejs/plugin-react';

// Production-only Content Security Policy. Not applied in dev because Vite's
// HMR needs inline scripts and websockets.
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: https:",
  "media-src 'self' https: blob:",
  "connect-src 'self' https:",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    // For GitHub Pages project sites set VITE_BASE_PATH=/<repo-name>/
    base: env.VITE_BASE_PATH || '/',
    plugins: [
      react(),
      {
        name: 'inject-csp',
        apply: 'build' as const,
        transformIndexHtml(html: string) {
          return html.replace(
            '</head>',
            `  <meta http-equiv="Content-Security-Policy" content="${CSP}" />\n  </head>`,
          );
        },
      },
    ],
    test: {
      environment: 'node',
      include: ['src/**/*.test.ts'],
      // Tests always run with the strict (production) URL policy.
      env: { VITE_ALLOW_INSECURE_DEV: 'false' },
    },
  };
});
